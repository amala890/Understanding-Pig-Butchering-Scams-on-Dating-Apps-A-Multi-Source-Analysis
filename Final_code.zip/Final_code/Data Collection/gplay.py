import pandas as pd
from google_play_scraper import Sort, reviews


def fetch_reviews(app_id, max_reviews=200):
    all_reviews = []
    continuation_token = None

   
    while len(all_reviews) < max_reviews:
        result, continuation_token = reviews(
            app_id,
            lang="en", 
            country="us", 
            sort=Sort.NEWEST,  
            continuation_token=continuation_token,
        )
        all_reviews.extend(result)
        if continuation_token is None:
            break

    return all_reviews[:max_reviews]


def main():
   
    app_id = "com.tinder"  # Replace with the correct app ID for other apps
    max_reviews = 50000  
    keywords = ["Investment", "fraud", "fake profiles", "cheat", "hacked", "stolen", "money", "Bitcoin", 
                "trading platform","cryptocurrency","romancescam","Gained my trust", "asked for money", "built a relationship",
                "pig-butchering","phishing","dating app scam"] #changes as per needs
                
 

    try:
      
        reviews_data = fetch_reviews(app_id, max_reviews)

 
        df = pd.DataFrame(reviews_data)

        
        df["scam_related"] = df["content"].apply(
            lambda x: any(keyword in x.lower() for keyword in keywords) if isinstance(x, str) else False
        )

       
        df = df[[
            "reviewId", "userName", "userImage", "content", "score",
            "thumbsUpCount", "reviewCreatedVersion", "at", "replyContent",
            "repliedAt", "scam_related"
        ]]

       
        df.rename(columns={
            "reviewCreatedVersion": "appVersion",
            "thumbsUpCount": "thumbsUp",
        }, inplace=True)

        # Save to CSV
        output_file = "tinder_reviews.csv"
        df.to_csv(output_file, index=False)
        print(f"Reviews saved to {output_file}.")

    except Exception as e:
        print(f"Error processing app: {e}")

if __name__ == "__main__":
    main()
