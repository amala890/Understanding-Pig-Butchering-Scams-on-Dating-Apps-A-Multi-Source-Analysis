import praw
import csv
import requests
import os


reddit = praw.Reddit(
    client_id="",
    client_secret="",
    user_agent="",
    username="",
    password=""
)


subreddits = ["CryptoToFuture"] 
                


keyword = [
        #"Pig butchering", 
        "lovescams", 
        "phonescams",
        "nigeriascams",
        #"cryptoscams",
        #"Pig-baiting",
        #"Investment scam",
        #"Financial scam",
        #"romancescams",
        #"Telegram scam",
        #"WhatsApp scam",
        #"Signal scam",
        #"Text message scam",
        "Dating app scam"]           
        # Replace with the actual keyword you want to search 



os.makedirs('images', exist_ok=True)

# Open a CSV file for writing
with open('reddit_posts.csv', mode='w', newline='', encoding='utf-8') as csv_file:
    fieldnames = ['Subreddit', 'Title', 'ID', 'Author', 'URL', 'Content', 'Image']
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    
    # Write the header
    writer.writeheader()
    
    for subreddit_name in subreddits:
        subreddit = reddit.subreddit(subreddit_name)
        print(f"\nSearching in subreddit: {subreddit_name}")
        
        # Search for posts with the keyword
        search_results = subreddit.search(keyword)
        
        for post in search_results:
            print("Title -", post.title)
            print("ID -", post.id)
            print("Author -", post.author)
            print("URL -", post.url)
            print("Content -", post.selftext[:300])  # Print the first 100 characters of the content for preview
            print("-" * 30)
            
            
            image_filename = ''
            
            
            if post.url.endswith(('jpg', 'jpeg', 'png', 'gif')):
                try:
                   
                    response = requests.get(post.url)
                    if response.status_code == 200:
                       
                        image_filename = os.path.join('images', f"{post.id}.{post.url.split('.')[-1]}")
                        with open(image_filename, 'wb') as img_file:
                            img_file.write(response.content)
                except Exception as e:
                    print(f"Failed to download image: {e}")
            
            
            writer.writerow({
                'Subreddit': subreddit_name,
                'Title': post.title,
                'ID': post.id,
                'Author': str(post.author),
                'URL': post.url,
                'Content': post.selftext,
                'Image': image_filename
            })
