from ntscraper import Nitter
import pandas as pd
from pprint import pprint

def create_hashtag_tweets_dataset(hashtag, no_of_tweets):
    scraper = Nitter(log_level=1, skip_instance_check=False)
    tweets = scraper.get_tweets(hashtag, mode="hashtag", number=no_of_tweets)
    
    data = {
        'link': [],
        'text': [],
        'user': [],
        'likes': [],
        'quotes': [],
        'retweets': [],
        'comments': []
    }

    for tweet in tweets['tweets']:
        data['link'].append(tweet['link'])
        data['text'].append(tweet['text'])
        data['user'].append(tweet['user']['name'])
        data['likes'].append(tweet['stats']['likes'])
        data['quotes'].append(tweet['stats']['quotes'])
        data['retweets'].append(tweet['stats']['retweets'])
        data['comments'].append(tweet['stats']['comments'])

    df = pd.DataFrame(data)
    df.to_csv(hashtag+"_tweets_data.csv", index=False)
    return df


df = create_hashtag_tweets_dataset("tinderscam", 100)
pprint(df.head())


