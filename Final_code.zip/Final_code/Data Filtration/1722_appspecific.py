import os
import pandas as pd
import re
from collections import defaultdict


scam_indicators = {
    "app_specific_complaints": [
        "app didn’t remove the scammer even after reports", "no way to verify accounts",
        "scammers are not being flagged", "app is not doing enough to stop scams",
        "reports not taken seriously", "scammers are not removed", "no scam detection system in place",
        "no follow-up after reporting", "app does nothing about scammers", "ignored my report",
        "no safety measures in place", "fraudulent accounts not flagged", "too many scammers on the platform",
        "scam reports go unanswered", "reports get dismissed", "no actions taken on scam reports",
        "app lacks proper monitoring", "scam detection is poor", "lack of action against scammer profiles",
        "no mechanism to prevent scams", "fake profiles", "scammers are not filtered out",
        "unable to report scams", "app doesn't block scammers", "scammers on every profile",
        "no way to identify fake profiles", "scammer problem is out of control", "app doesn't have security measures",
        "profiles aren’t verified", "scam reports aren’t followed up", "scam report feature broken",
        "no account verification system", "fake accounts run rampant", "verification doesn’t work",
        "fake users are everywhere", "no way to confirm identity", "app not monitoring profiles",
        "no verification checks", "fake messages from scammers", "scammer profile keeps popping up",
        "scammers bypass security", "cannot report fake accounts", "no way to prevent scammer messages",
        "fake profiles slip through"
    ],
    "suggestions_for_improved_safety": [
        "needs better verification", "should screen profiles better", "needs stricter account verification",
        "app should require ID verification", "more robust account verification", "profile verification process should be improved",
        "better protection against scammers", "implement background checks", "add two-factor authentication",
        "more secure user verification", "add better security features", "increase profile verification methods",
        "require more identity checks", "add face recognition for verification", "better ways to flag scammers",
        "better moderation of profiles", "screen for fake profiles", "better privacy policies", "verification process needs to be stricter",
        "screening process for users is weak", "more comprehensive safety checks", "app needs to improve security",
        "better tools for identifying fake accounts", "stronger scam prevention tools", "more identity checks needed",
        "app needs to verify users", "require identity verification before chatting", "implement face verification",
        "require government-issued ID", "need more user identity confirmation", "profile screening should be more thorough",
        "needs manual review of profiles", "implement a scammer blacklist", "better moderation for profiles",
        "verification should be more strict", "stronger profile verification methods", "improve user safety features",
        "require selfie verification", "add real-time profile moderation", "profile verification should be mandatory",
        "improve security to prevent scams", "use AI to detect fake profiles", "add a flagging system for suspicious users"
    ]
}

def classify_review(text):
    text = text.lower()
    category_counts = defaultdict(int)
    for category, keywords in scam_indicators.items():
        for keyword in keywords:
            if re.search(r"\b" + re.escape(keyword) + r"\b", text):
                category_counts[category] += 1
    return category_counts

def process_by_app(file_path):
    try:
        df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

    if "content" not in df.columns or "App" not in df.columns:
        print("Missing required columns ('content' and 'App') in the file.")
        return None

    results = defaultdict(lambda: defaultdict(int))

    for _, row in df.iterrows():
        app_name = row.get("App", "Unknown").strip()
        review_text = str(row["content"])
        category_counts = classify_review(review_text)

        for category, count in category_counts.items():
            results[app_name][category] += count

    
    data = []
    for app, counts in results.items():
        row = {
            "App Name": app,
            "app_specific_complaints": counts.get("app_specific_complaints", 0),
            "suggestions_for_improved_safety": counts.get("suggestions_for_improved_safety", 0)
        }
        data.append(row)

    return pd.DataFrame(data)

import os

folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
file_name = "DatingAppReviewsDataset2017-22.csv"
file_path = os.path.join(folder_path, file_name)

output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\app_specific_results"
os.makedirs(output_folder, exist_ok=True)


df_app_summary = process_by_app(file_path)
if df_app_summary is not None:
    output_file = os.path.join(output_folder, "app_specific_summary_by_app.csv")
    df_app_summary.to_csv(output_file, index=False)
    print("✅ App-specific scam indicator summary saved to:", output_file)
else:
    print("❌ Failed to generate results.")
