import os
import pandas as pd
from collections import defaultdict


platform_keywords = {
    "whatsapp": ["whatsapp", "whats app"],
    "telegram": ["telegram", "tele gram"],
    "instagram": ["instagram", "insta"],
    "facebook": ["facebook", "fb messenger"],
    "snapchat": ["snapchat", "snap chat"],
    "skype": ["skype"],
    "signal": ["signal"],
    "line": ["line app"],
    "wechat": ["wechat", "we chat"]
}

def classify_platforms(text):
    text = text.lower()
    result = defaultdict(int)
    for platform, keywords in platform_keywords.items():
        for keyword in keywords:
            if keyword in text:
                result[platform] += 1
    return result

def process_platform_mentions(folder_path):
    summary = defaultdict(lambda: {platform: 0 for platform in platform_keywords})
    matching_reviews = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, encoding="ISO-8859-1")

            if "content" not in df.columns or "App" not in df.columns:
                print(f"Skipping {file} due to missing required columns.")
                continue

            for _, row in df.iterrows():
                app_name = str(row["App"]).strip()
                text = str(row["content"]).strip()
                platform_hits = classify_platforms(text)

                if platform_hits:
                    for platform, count in platform_hits.items():
                        summary[app_name][platform] += count
                    matching_reviews.append([app_name, text, list(platform_hits.keys())])

    return pd.DataFrame.from_dict(summary, orient="index").reset_index().rename(columns={"index": "App Name"}), matching_reviews

def save_platform_results(summary_df, matching_reviews, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    summary_path = os.path.join(output_folder, "platform_mentions_summary.csv")
    summary_df.to_csv(summary_path, index=False)

    review_df = pd.DataFrame(matching_reviews, columns=["App Name", "Review Content", "Platforms Mentioned"])
    review_path = os.path.join(output_folder, "platform_classified_reviews.csv")
    review_df.to_csv(review_path, index=False)

    print("Platform analysis and review file saved.")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\platform_reviews"

summary_df, matching_reviews = process_platform_mentions(folder_path)
save_platform_results(summary_df, matching_reviews, output_folder)
