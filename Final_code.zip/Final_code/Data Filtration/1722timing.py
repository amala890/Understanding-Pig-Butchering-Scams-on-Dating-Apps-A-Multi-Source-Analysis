import os
import pandas as pd
from collections import defaultdict


timing_indicators = {
    "quick_escalation": [
        "within days", "suddenly asked", "out of nowhere",
        "started talking about money", "pivot to investments",
        "within a week", "few days later", "quickly changed"
    ],
    "delayed_escalation": [
        "after weeks", "months later", "gained trust first",
        "waited before asking"
    ]
}

def classify_timing(text):
    text = text.lower()
    result = {"quick_escalation": 0, "delayed_escalation": 0}

    for category, keywords in timing_indicators.items():
        for keyword in keywords:
            if keyword in text:
                result[category] += 1

    return result

def process_timing_patterns(folder_path):
    summary = defaultdict(lambda: {"quick_escalation": 0, "delayed_escalation": 0, "no_mention": 0})
    matching_reviews = []  # Store matched reviews

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, encoding="ISO-8859-1")

            if "content" not in df.columns or "App" not in df.columns:
                print(f"Skipping {file} due to missing required columns.")
                continue

            for _, row in df.iterrows():
                app_name = str(row["App"]).strip()
                text = str(row["content"]).strip()
                text_lower = text.lower()

                timing_result = classify_timing(text_lower)
                quick = timing_result["quick_escalation"]
                delayed = timing_result["delayed_escalation"]

                if quick > 0:
                    summary[app_name]["quick_escalation"] += 1
                    matching_reviews.append([app_name, text, "quick_escalation"])
                elif delayed > 0:
                    summary[app_name]["delayed_escalation"] += 1
                    matching_reviews.append([app_name, text, "delayed_escalation"])
                else:
                    summary[app_name]["no_mention"] += 1

    
    summary_data = []
    for app, counts in summary.items():
        total = counts["quick_escalation"] + counts["delayed_escalation"] + counts["no_mention"]
        ratio = (counts["quick_escalation"] + counts["delayed_escalation"]) / total if total else 0
        summary_data.append({
            "app_name": app,
            "quick_escalation": counts["quick_escalation"],
            "delayed_escalation": counts["delayed_escalation"],
            "no_mention": counts["no_mention"],
            "escalation_ratio": round(ratio, 3)
        })

    return pd.DataFrame(summary_data), matching_reviews

def save_timing_results(summary_df, matching_reviews, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    
    summary_path = os.path.join(output_folder, "timing_patterns_summary.csv")
    summary_df.to_csv(summary_path, index=False)

    
    review_df = pd.DataFrame(matching_reviews, columns=["App Name", "Review Content", "Timing Category"])
    review_path = os.path.join(output_folder, "timing_classified_reviews.csv")
    review_df.to_csv(review_path, index=False)

    print("Timing pattern analysis and review file saved.")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\timing_patterns"

summary_df, matching_reviews = process_timing_patterns(folder_path)
save_timing_results(summary_df, matching_reviews, output_folder)

