import os
import re
import pandas as pd
from collections import defaultdict


victim_keywords = [
    "romance scam", "pig butchering", "crypto scam", "investment scam", "crypto romance scam",
    "financial scam", "crypto fraud", "crypto scheme", "crypto trading scam", "lost my savings",
    "fake investment", "fake platform", "asked me to invest", "pushed me to invest",
    "asked me to download an app", "they introduced me to a mentor", "built trust and then",
    "pressured me to invest", "sent me a trading link", "i was added to a crypto group",
    "talked for weeks before asking for money", "he said he was a crypto trader",
    "she said she worked in crypto", "claimed to help me invest", "showed fake profits",
    "sent screenshots of returns", "i trusted them with my savings", "couldn’t withdraw",
    "wallet got drained", "they tricked me", "they promised high returns",
    "used a fake trading app", "sent money and then they disappeared",
    "they ghosted me after i sent money", "said we were soulmates and then asked for bitcoin",
    "said they lived abroad and needed help", "they wanted me to transfer crypto",
    "i lost thousands", "money vanished", "i got duped", "i was defrauded",
    "they convinced me to invest", "he made me believe it was real", "promised guaranteed profits",
    "told me i could double my money", "we met on a dating app and then...", "fake broker",
    "binance scam", "metamask scam", "they blocked me after i paid", "i thought it was love",
    "everything seemed perfect until money came up",
]

def classify_review(text):
    text = text.lower()
    for keyword in victim_keywords:
        if re.search(keyword, text):
            return "Victim"
    return "Not Scam Related"

def extract_app_name(file_name):
    return os.path.splitext(file_name)[0]

def process_public_dataset(folder_path):
    results = defaultdict(lambda: {"Victims": 0, "Total Reviews": 0})
    all_reviews = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, dtype=str, low_memory=False)

            has_app_name_column = "app_name" in df.columns
            app_name = extract_app_name(file) if not has_app_name_column else None

            required_columns = {"content", "userName"}
            optional_columns = ["score", "thumbsUpCount", "reviewCreatedVersion", "at", "replyContent", "repliedAt"]

            if not required_columns.issubset(df.columns):
                print(f"Skipping {file} due to missing required columns.")
                continue

            for _, row in df.iterrows():
                review_text = str(row["content"])

                if has_app_name_column:
                    app_name = row["app_name"]

                category = classify_review(review_text)
                results[app_name]["Total Reviews"] += 1

                if category == "Victim":
                    review_data = {
                        "App Name": app_name,
                        "User Name": row.get("userName", ""),
                        "Review Content": review_text,
                        "Score": row.get("score", ""),
                        "ThumbsUp Count": row.get("thumbsUpCount", ""),
                        "Review Version": row.get("reviewCreatedVersion", ""),
                        "Review Date": row.get("at", ""),
                        "Reply Content": row.get("replyContent", ""),
                        "Replied At": row.get("repliedAt", "")
                    }
                    all_reviews.append(review_data)
                    results[app_name]["Victims"] += 1

    return results, all_reviews

def save_public_results(results, all_reviews, output_folder):
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)

   
    total_row = {
        "App Name": "TOTAL",
        "Victims": summary_df["Victims"].sum(),
        "Total Reviews": summary_df["Total Reviews"].sum()
    }
    summary_df = pd.concat([summary_df, pd.DataFrame([total_row])], ignore_index=True)

    summary_df.to_csv(os.path.join(output_folder, "victim_summary.csv"), index=False)

    review_df = pd.DataFrame(all_reviews)
    review_df.to_csv(os.path.join(output_folder, "victim_reviews.csv"), index=False)

    print("Processing complete. Victim-only results saved.")


public_dataset_folder = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\Kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"

results, all_reviews = process_public_dataset(public_dataset_folder)
save_public_results(results, all_reviews, output_folder)
