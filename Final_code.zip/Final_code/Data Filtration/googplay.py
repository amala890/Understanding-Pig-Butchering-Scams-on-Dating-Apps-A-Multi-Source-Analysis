import pandas as pd
import os
from textblob import TextBlob
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import seaborn as sns


input_dir = r'C:\Users\hp\Desktop\Full_code_Amala_Romance\GooglePlayreviews_Final'
output_dir = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
os.makedirs(output_dir, exist_ok=True)


scam_keywords = [
    "investment", "crypto", "Bitcoin", "trading", "profits", "returns", "money",
    "financial advisor", "business opportunity", "forex", "stock market", "wealth",
    "passive income", "get rich quick", "high returns", "low risk", "financial freedom",
    "cryptocurrency", "blockchain", "wallet address", "send money", "bank transfer",
    "payment", "funds", "scam", "fraud", "fake", "cheat", "swindle", "con artist",
    "scammer", "scamming", "scammed", "trust", "love", "relationship", "romance",
    "emotional", "manipulation", "soulmate", "marriage", "commitment", "future together",
    "true love", "heartbroken", "broken trust", "lied to", "deceived", "betrayed",
    "fake love", "pretend", "emotional scam", "romance scam", "catfish", "fake profile",
    "fake identity", "fake person", "fake account", "too good to be true", "frequent traveler",
    "living abroad", "avoid meeting", "external app", "WhatsApp", "Telegram", "Skype",
    "Line", "WeChat", "move to another app", "private chat", "secretive", "no video call",
    "no phone call", "no meetup", "avoid in-person", "long distance", "military",
    "engineer", "doctor", "oil rig", "working overseas", "urgent", "emergency",
    "need money", "financial help", "help me", "desperate", "quick money", "urgent request",
    "urgent need", "urgent help", "urgent situation", "fake profiles", "no verification",
    "scammers everywhere", "no moderation", "no support", "reported but no action",
    "fake accounts", "bot accounts", "spam accounts", "hacked", "security issues",
    "privacy concerns", "data breach", "stolen identity", "stolen photos",
    "stolen information", "phishing", "malware", "virus", "unsafe", "dangerous",
    "untrustworthy", "unreliable", "no customer service", "no response", "ignored reports",
    "ignored complaints"
]


profile_behavior_keywords = {
    "generic_pictures": ["generic photos", "stock images", "model-like pictures", "too perfect photos"],
    "living_abroad": ["living abroad", "working overseas", "based in another country", "expat"],
    "inconsistent_profiles": ["fake profile", "stolen photos", "catfish", "details don't match", "lied about age/job"],
    "pushing_investments": ["investments", "crypto", "trading", "side hustle", "send money"],
    "off_platform_moves": ["WhatsApp", "Telegram", "move to another app", "chat outside"],
    "avoiding_meetings": ["won't video call", "refused to meet", "excuses to not meet", "always traveling"]
}


def detect_scam(content):
    if isinstance(content, str):
        content_lower = content.lower()
        return any(keyword in content_lower for keyword in scam_keywords)
    return False

def get_sentiment(content):
    if isinstance(content, str):
        return TextBlob(content).sentiment.polarity
    return 0

def flag_keyword_mentions(text, keyword_group):
    if not isinstance(text, str):
        return False
    text_lower = text.lower()
    return any(keyword in text_lower for keyword in keyword_group)


csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]
all_scam_reviews = []

for file in csv_files:
    app_name = file.replace('_reviews.csv', '').replace('.csv', '')
    print(f"\n📄 Processing {file}...")
    try:
        df = pd.read_csv(os.path.join(input_dir, file), encoding='utf-8')
    except UnicodeDecodeError:
        print(f"⚠️ UTF-8 decode failed for {file}, trying latin-1...")
        df = pd.read_csv(os.path.join(input_dir, file), encoding='latin-1')
    except Exception as e:
        print(f"❌ Failed to load {file}: {e}")
        continue

    if 'content' not in df.columns:
        print("⚠️ 'content' column missing, skipping.")
        continue

    df['content'] = df['content'].fillna('').astype(str)
    df['is_scam'] = df['content'].apply(detect_scam)
    df['sentiment'] = df['content'].apply(get_sentiment)

    scam_reviews = df[df['is_scam']].copy()
    if not scam_reviews.empty:
        scam_reviews['app_name'] = app_name
        all_scam_reviews.append(scam_reviews)
        print(f"✅ Scam reviews detected: {len(scam_reviews)}")
    else:
        print("🟡 No scam reviews found.")


if all_scam_reviews:
    all_scam_reviews_df = pd.concat(all_scam_reviews, ignore_index=True)

    
    scam_output_path = os.path.join(output_dir, 'scam_reviews_combined.csv')
    all_scam_reviews_df.to_csv(scam_output_path, index=False)
    print(f"\n✅ Combined scam reviews saved: {scam_output_path}")

   
    scam_text = " ".join(all_scam_reviews_df['content'].dropna())
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(scam_text)
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.title('Word Cloud of Scam-Related Keywords')
    wordcloud_path = os.path.join(output_dir, 'scam_wordcloud.png')
    plt.savefig(wordcloud_path)
    plt.close()
    print(f"🖼️ Word cloud saved to: {wordcloud_path}")

    
    scam_counts = all_scam_reviews_df['app_name'].value_counts().reset_index()
    scam_counts.columns = ['app_name', 'scam_count']
    plt.figure(figsize=(16, 10))
    sns.barplot(x='app_name', y='scam_count', data=scam_counts)
    plt.xlabel('Dating App')
    plt.ylabel('Number of Scam-Related Reviews')
    plt.title('Scam Prevalence by Dating App')
    plt.xticks(rotation=90)
    plt.tight_layout()
    barplot_path = os.path.join(output_dir, 'scam_prevalence_barplot.png')
    plt.savefig(barplot_path)
    plt.close()
    print(f"📊 Scam bar plot saved to: {barplot_path}")

    
    for category, keywords in profile_behavior_keywords.items():
        all_scam_reviews_df[f"flag_{category}"] = all_scam_reviews_df["content"].apply(
            lambda x: flag_keyword_mentions(x, keywords)
        )

    all_scam_reviews_df["has_any_red_flag"] = all_scam_reviews_df[[
        f"flag_{category}" for category in profile_behavior_keywords.keys()
    ]].any(axis=1)

   
    flagged_texts = all_scam_reviews_df[all_scam_reviews_df["has_any_red_flag"]]["content"]
    flagged_texts_path = os.path.join(output_dir, "flagged_reviews_text_only.csv")
    flagged_texts.to_csv(flagged_texts_path, index=False, header=["review_text"])
    print(f"📄 Flagged red-flag review texts saved to: {flagged_texts_path}")

    
    profile_behavior_stats = all_scam_reviews_df.groupby("app_name").agg({
        "flag_generic_pictures": "sum",
        "flag_living_abroad": "sum",
        "flag_inconsistent_profiles": "sum",
        "flag_pushing_investments": "sum",
        "flag_off_platform_moves": "sum",
        "flag_avoiding_meetings": "sum",
        "is_scam": "sum"
    }).reset_index()

    profile_behavior_stats.columns = [
        "App_Name", "Generic_Pictures_Mentions", "Living_Abroad_Mentions",
        "Inconsistent_Profiles_Mentions", "Pushing_Investments_Mentions",
        "Off_Platform_Moves_Mentions", "Avoiding_Meetings_Mentions", "Total_Scam_Reviews"
    ]

    profile_csv_path = os.path.join(output_dir, "profile_behavior_insights_by_app.csv")
    profile_behavior_stats.to_csv(profile_csv_path, index=False)
    print(f"✅ Profile/behavioral flags saved to: {profile_csv_path}")

    
    plt.figure(figsize=(20, 9))
    melted_df = profile_behavior_stats.melt(id_vars="App_Name", var_name="Metric", value_name="Count")
    sns.barplot(data=melted_df, x="App_Name", y="Count", hue="Metric")
    plt.title("Profile/Behavioral Red Flags by App")
    plt.xticks(rotation=90)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    redflag_plot_path = os.path.join(output_dir, "profile_behavioral_redflags_barplot.png")
    plt.savefig(redflag_plot_path)
    plt.close()
    print(f"📊 Profile/behavioral bar plot saved to: {redflag_plot_path}")

else:
    print("\n❌ No scam-related reviews found in any app.")
