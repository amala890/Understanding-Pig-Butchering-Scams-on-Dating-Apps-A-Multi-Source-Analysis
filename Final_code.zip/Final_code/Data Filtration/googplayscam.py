import pandas as pd
import os
from textblob import TextBlob
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import seaborn as sns


input_dir = r'C:\Users\hp\Desktop\Full_code_Amala_Romance\GooglePlayreviews_Final'
output_dir = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
os.makedirs(output_dir, exist_ok=True)

csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]


scam_keywords = [
    "investment", "crypto", "Bitcoin", "trading", "profits", "returns", "money",
    "financial advisor", "business opportunity", "forex", "stock market", "wealth",
    "passive income", "get rich quick", "high returns", "low risk", "financial freedom",
    "cryptocurrency", "blockchain", "wallet address", "send money", "bank transfer",
    "payment", "funds", "scam", "fraud", "fake", "cheat", "swindle", "con artist",
    "scammer", "scamming", "scammed", "trust", "love", "relationship", "romance",
    "emotional", "manipulation", "soulmate", "marriage", "commitment", "future together",
    "true love", "heartbroken", "broken trust", "lied to", "deceived", "betrayed",
    "fake love", "pretend", "emotional scam", "romance scam", "catfish", "fake profile",
    "fake identity", "fake person", "fake account", "too good to be true", "frequent traveler",
    "living abroad", "avoid meeting", "external app", "WhatsApp", "Telegram", "Skype",
    "Line", "WeChat", "move to another app", "private chat", "secretive", "no video call",
    "no phone call", "no meetup", "avoid in-person", "long distance", "military",
    "engineer", "doctor", "oil rig", "working overseas", "urgent", "emergency",
    "need money", "financial help", "help me", "desperate", "quick money", "urgent request",
    "urgent need", "urgent help", "urgent situation", "fake profiles", "no verification",
    "scammers everywhere", "no moderation", "no support", "reported but no action",
    "fake accounts", "bot accounts", "spam accounts", "hacked", "security issues",
    "privacy concerns", "data breach", "stolen identity", "stolen photos",
    "stolen information", "phishing", "malware", "virus", "unsafe", "dangerous",
    "untrustworthy", "unreliable", "no customer service", "no response", "ignored reports",
    "ignored complaints"
]

def detect_scam(content):
    if isinstance(content, str):
        content_lower = content.lower()
        return any(keyword in content_lower for keyword in scam_keywords)
    return False

def get_sentiment(content):
    if isinstance(content, str):
        return TextBlob(content).sentiment.polarity
    return 0

dataframes = {}
all_scam_reviews = []


for file in csv_files:
    app_name = file.replace('_reviews.csv', '').replace('.csv', '')
    print(f"\n📄 Processing file: {file}")
    
    try:
        df = pd.read_csv(os.path.join(input_dir, file), encoding='utf-8')
    except UnicodeDecodeError:
        print(f"⚠️ UTF-8 decode failed for {file}, trying latin-1...")
        df = pd.read_csv(os.path.join(input_dir, file), encoding='latin-1')
    except Exception as e:
        print(f"❌ Could not read {file}: {e}")
        continue

    if 'content' not in df.columns:
        print(f"⚠️ 'content' column not found in {file}, skipping...")
        continue

    df['content'] = df['content'].fillna('').astype(str)

    
    df = df.head(100)

    df['is_scam'] = df['content'].apply(detect_scam)
    df['sentiment'] = df['content'].apply(get_sentiment)

    scam_reviews = df[df['is_scam']].copy()
    if not scam_reviews.empty:
        scam_reviews['app_name'] = app_name
        all_scam_reviews.append(scam_reviews)
        print(f"✅ Scam reviews found: {len(scam_reviews)}")
    else:
        print("🟡 No scam reviews found.")

    dataframes[app_name] = df

if all_scam_reviews:
    all_scam_reviews_df = pd.concat(all_scam_reviews, ignore_index=True)
    
    
    scam_csv_path = os.path.join(output_dir, 'scam_reviews_combined_TEST.csv')
    all_scam_reviews_df.to_csv(scam_csv_path, index=False, encoding='utf-8')
    print(f"\n✅ Scam reviews saved to: {scam_csv_path}")

    
    scam_text = " ".join(all_scam_reviews_df['content'].dropna())
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(scam_text)
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.title('Word Cloud of Scam-Related Reviews')
    wordcloud_path = os.path.join(output_dir, 'scam_wordcloud_TEST.png')
    plt.savefig(wordcloud_path)
    plt.close()
    print(f"🖼️ Word cloud saved to: {wordcloud_path}")

    
    scam_prevalence = all_scam_reviews_df['app_name'].value_counts().reset_index()
    scam_prevalence.columns = ['app_name', 'scam_count']
    plt.figure(figsize=(16, 10))
    sns.barplot(x='app_name', y='scam_count', data=scam_prevalence)
    plt.xlabel('Dating App')
    plt.ylabel('Number of Scam-Related Reviews')
    plt.title('Scam Prevalence by Dating App')
    plt.xticks(rotation=90)
    plt.tight_layout()
    barplot_path = os.path.join(output_dir, 'scam_prevalence_barplot_TEST.png')
    plt.savefig(barplot_path)
    plt.close()
    print(f"📊 Bar plot saved to: {barplot_path}")
else:
    print("\n❌ No scam-related reviews found in any file.")
