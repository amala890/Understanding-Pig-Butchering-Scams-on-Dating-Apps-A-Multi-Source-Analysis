import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'


input_file = os.path.join(input_folder, 'scam_reviews_combined.csv')
all_scam_reviews_df = pd.read_csv(input_file)


platform_keywords = {
    "crypto_wallets": ["crypto wallet", "blockchain address", "BTC address", "ETH wallet"],
    "investment_sites": ["investment portal", "trading platform", "forex site", "binance", "coinbase", "fake exchange"],
    "payment_apps": ["PayPal", "Venmo", "CashApp", "Zelle", "Western Union"],
    "whatsapp": ["WhatsApp", "whats app"],
    "telegram": ["Telegram", "tele gram"],
    "skype": ["Skype"],
    "suspicious_links": ["suspicious link", "phishing site", "fake website", "http://", "https://"]
}


def flag_platforms(text):
    platforms = []
    if isinstance(text, str):
        text_lower = text.lower()
        for platform, keywords in platform_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                platforms.append(platform)
    return platforms if platforms else None


all_scam_reviews_df["mentioned_platforms"] = all_scam_reviews_df["content"].apply(flag_platforms)


platform_mentions = all_scam_reviews_df.explode("mentioned_platforms").dropna(subset=["mentioned_platforms"])
platform_stats = (
    platform_mentions.groupby(["app_name", "mentioned_platforms"])
    .size()
    .unstack(fill_value=0)
    .reset_index()
)


platform_stats.to_csv(os.path.join(output_folder, "platform_mentions_by_app.csv"), index=False)


melted_platforms = platform_stats.melt(
    id_vars="app_name",
    var_name="platform",
    value_name="mentions"
)


plt.figure(figsize=(20, 9))
sns.barplot(
    data=melted_platforms.sort_values("mentions", ascending=False),
    x="platform",
    y="mentions",
    hue="app_name"
)
plt.title("Most Mentioned External Platforms in Scam Reviews")
plt.xticks(rotation=90)
plt.ylabel("Number of Mentions")
plt.legend(title="Dating App")
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "platform_mentions_barplot.png"))
plt.show()


platform_reviews = all_scam_reviews_df[all_scam_reviews_df["mentioned_platforms"].notna()]
platform_reviews.to_csv(os.path.join(output_folder, "four_all_reviews_mentioning_platforms.csv"), index=False)
