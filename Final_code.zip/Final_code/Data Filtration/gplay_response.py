import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = input_folder


file_path = os.path.join(input_folder, "scam_reviews_combined.csv")
all_scam_reviews_df = pd.read_csv(file_path)


scam_response_keywords = [
    "scam", "fraud", "fake profile", "investigation", "removed this account",
    "violation", "policy", "report", "safety", "verification", "ban"
]


if 'replyContent' in all_scam_reviews_df.columns:
    developer_responses = all_scam_reviews_df[all_scam_reviews_df['replyContent'].notna()].copy()
    print(f"Found {len(developer_responses)} developer responses.")

    
    developer_responses['acknowledges_scam'] = developer_responses['replyContent'].str.lower().str.contains(
        '|'.join(scam_response_keywords), na=False
    )

    
    scam_reviews_with_response = developer_responses['is_scam'].sum()
    scam_acknowledgement_rate = developer_responses['acknowledges_scam'].mean() * 100

    print(f"\nScam reviews with developer response: {scam_reviews_with_response}")
    print(f"Responses acknowledging scams: {scam_acknowledgement_rate:.1f}%")

    
    print("\nExamples of scam acknowledgements:")
    for response in developer_responses[developer_responses['acknowledges_scam']]['replyContent'].head(5):
        print(f"- {response}\n")

    
    if 'repliedAt' in all_scam_reviews_df.columns and 'at' in all_scam_reviews_df.columns:
        developer_responses['repliedAt_dt'] = pd.to_datetime(developer_responses['repliedAt'], format="%m-%d-%Y %H:%M", errors='coerce')
        developer_responses['at_dt'] = pd.to_datetime(developer_responses['at'], format="%m-%d-%Y %H:%M", errors='coerce')
        developer_responses['response_time_days'] = (developer_responses['repliedAt_dt'] - developer_responses['at_dt']).dt.days
        avg_response_time = developer_responses['response_time_days'].mean()
        print(f"\nAverage response time: {avg_response_time:.1f} days")
    else:
        print("\nTimestamp columns missing - cannot compute response time.")

    
    response_stats = developer_responses.groupby('app_name')['acknowledges_scam'].mean() * 100

    plt.figure(figsize=(20, 6))
    sns.barplot(
        data=response_stats.reset_index(),
        x='app_name',
        y='acknowledges_scam',
        color='orange'
    )
    plt.title("Percentage of Developer Responses That Acknowledge Scams")
    plt.ylabel("Scam Acknowledgement Rate (%)")
    plt.xlabel("App Name")
    plt.xticks(rotation=90)
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.show()

    
    acknowledged_responses = developer_responses[developer_responses['acknowledges_scam']].copy()
    columns_to_save = ['app_name', 'score', 'content', 'replyContent', 'sentiment', 'is_scam']
    output_csv = os.path.join(output_folder, 'scam_acknowledged_developer_responses.csv')
    acknowledged_responses[columns_to_save].to_csv(output_csv, index=False)
    print(f"\nSaved {len(acknowledged_responses)} responses to '{output_csv}'")

else:
    print("No 'replyContent' column found - cannot analyze developer responses.")
