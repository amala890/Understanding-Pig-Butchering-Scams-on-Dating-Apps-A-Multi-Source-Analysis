import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import re


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = input_folder


input_file = os.path.join(input_folder, "scam_reviews_combined.csv")
all_scam_reviews_df = pd.read_csv(input_file)


scam_keywords = ["scam", "fraud", "fake", "phishing", "investment", "crypto", "bitcoin", "romance", "catfish"] #change

def detect_scam(text):
    if isinstance(text, str):
        text_lower = text.lower()
        return any(keyword in text_lower for keyword in scam_keywords)
    return False


if 'score' in all_scam_reviews_df.columns:
    
    low_score_reviews = all_scam_reviews_df[
        (all_scam_reviews_df['score'] <= 2) & 
        (all_scam_reviews_df['score'] >= 1)
    ].copy()

    print(f"Found {len(low_score_reviews)} low-score (1-2 star) reviews.")

    
    low_score_reviews['is_scam'] = low_score_reviews['content'].apply(detect_scam)

    
    if 'is_scam' not in all_scam_reviews_df.columns:
        all_scam_reviews_df['is_scam'] = all_scam_reviews_df['content'].apply(detect_scam)

    scam_rate_low = low_score_reviews['is_scam'].mean() * 100
    scam_rate_high = all_scam_reviews_df[all_scam_reviews_df['score'] > 2]['is_scam'].mean() * 100

    print(f"Scam mention rates:\n- Low-score (1-2 stars): {scam_rate_low:.1f}%\n- High-score (3-5 stars): {scam_rate_high:.1f}%")

    
    def get_top_keywords(text, n=10):
        words = re.findall(r'\b\w+\b', text.lower())
        return Counter([w for w in words if w in scam_keywords]).most_common(n)

    low_score_text = " ".join(low_score_reviews['content'].fillna(''))
    high_score_text = " ".join(all_scam_reviews_df[all_scam_reviews_df['score'] > 2]['content'].fillna(''))

    top_low_score_keywords = get_top_keywords(low_score_text)
    top_high_score_keywords = get_top_keywords(high_score_text)

    print("\nTop scam keywords in LOW-score reviews:")
    for word, count in top_low_score_keywords:
        print(f"{word}: {count}")

    print("\nTop scam keywords in HIGH-score reviews:")
    for word, count in top_high_score_keywords:
        print(f"{word}: {count}")

    
    plt.figure(figsize=(8, 5))
    sns.barplot(
        x=['Low-Score (1-2)', 'High-Score (3-5)'],
        y=[scam_rate_low, scam_rate_high],
        palette=['red', 'green']
    )
    plt.title("Scam Mention Rate by Review Score")
    plt.ylabel("Percentage of Reviews Mentioning Scams")
    plt.show()

    
    if 'sentiment' in all_scam_reviews_df.columns:
        plt.figure(figsize=(10, 6))
        sns.boxplot(
            data=all_scam_reviews_df,
            x=pd.cut(all_scam_reviews_df['score'], bins=[0, 2, 5], labels=['Low (1-2)', 'High (3-5)']),
            y='sentiment',
            palette=['red', 'green']
        )
        plt.title("Sentiment Distribution by Review Score")
        plt.xlabel("Review Score Group")
        plt.ylabel("Sentiment Polarity")
        plt.show()

    
    low_score_scams = low_score_reviews[low_score_reviews['is_scam']]
    export_path_1 = os.path.join(output_folder, 'low_score_scam_reviews.csv')
    low_score_scams.to_csv(export_path_1, index=False)

   
    columns_to_save = ['app_name', 'score', 'content', 'is_scam']
    export_path_2 = os.path.join(output_folder, "seven_low_score_scam_review_contents.csv")
    low_score_scams[columns_to_save].to_csv(export_path_2, index=False)

    print(f"Exported {len(low_score_scams)} scam-related low-score reviews to:\n{export_path_1}\n{export_path_2}")

else:
    print("No 'score' column found in the dataset. Please check your DataFrame columns.")
