
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import re


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = input_folder


input_file = os.path.join(input_folder, "scam_reviews_combined.csv")
all_scam_reviews_df = pd.read_csv(input_file)


scam_keywords = ["scam", "fraud", "fake", "phishing", "investment", "crypto", "bitcoin", "romance", "catfish"]


def detect_scam(text):
    if isinstance(text, str):
        text_lower = text.lower()
        return any(keyword in text_lower for keyword in scam_keywords)
    return False


if 'is_scam' not in all_scam_reviews_df.columns:
    all_scam_reviews_df['is_scam'] = all_scam_reviews_df['content'].apply(detect_scam)


engagement_col = 'thumbsUp' if 'thumbsUp' in all_scam_reviews_df.columns else ('likes' if 'likes' in all_scam_reviews_df.columns else None)

if engagement_col:
    
    threshold = all_scam_reviews_df[engagement_col].quantile(0.9)
    high_engagement_reviews = all_scam_reviews_df[all_scam_reviews_df[engagement_col] >= threshold].copy()

    print(f"Analyzing {len(high_engagement_reviews)} high-engagement reviews (≥ {threshold} likes)")

   
    high_engagement_scam_rate = high_engagement_reviews['is_scam'].mean() * 100
    low_engagement_scam_rate = all_scam_reviews_df[all_scam_reviews_df[engagement_col] < threshold]['is_scam'].mean() * 100

    print(f"Scam mention rates:\n- High-engagement: {high_engagement_scam_rate:.1f}%\n- Low-engagement: {low_engagement_scam_rate:.1f}%")

    
    def get_engagement_keywords(text, n=15):
        words = re.findall(r'\b\w+\b', text.lower())
        return Counter([w for w in words if w in scam_keywords]).most_common(n)

    high_engagement_text = " ".join(high_engagement_reviews['content'].fillna(''))
    low_engagement_text = " ".join(all_scam_reviews_df[all_scam_reviews_df[engagement_col] < threshold]['content'].fillna(''))

    print("\nTop scam keywords in HIGH-engagement reviews:")
    for word, count in get_engagement_keywords(high_engagement_text):
        print(f"{word}: {count}")

    print("\nTop scam keywords in LOW-engagement reviews:")
    for word, count in get_engagement_keywords(low_engagement_text):
        print(f"{word}: {count}")

    
    plt.figure(figsize=(10, 6))
    sns.scatterplot(
        data=all_scam_reviews_df,
        x=engagement_col,
        y='sentiment' if 'sentiment' in all_scam_reviews_df.columns else None,
        hue='is_scam',
        palette={True: 'red', False: 'gray'},
        alpha=0.6
    )
    plt.title("Review Engagement vs. Sentiment (Scam vs. Non-Scam)")
    plt.xlabel(f"Number of {engagement_col}")
    plt.ylabel("Sentiment Polarity" if 'sentiment' in all_scam_reviews_df.columns else "Sentiment")
    if 'sentiment' in all_scam_reviews_df.columns:
        plt.yscale('symlog')  
    plt.legend(title="Scam Mention")
    plt.show()

    
    viral_scams = high_engagement_reviews[high_engagement_reviews['is_scam']].sort_values(engagement_col, ascending=False).head(5)

    print("\nMost Viral Scam Reviews:")
    for i, row in viral_scams.iterrows():
        print(f"\n🔥 {row[engagement_col]} likes (App: {row['app_name']}):")
        print(f"\"{row['content']}\"")

    
    export_path_1 = os.path.join(output_folder, 'high_engagement_scams.csv')
    high_engagement_reviews[high_engagement_reviews['is_scam']].to_csv(
        export_path_1,
        index=False,
        columns=['app_name', 'content', 'score', engagement_col, 'sentiment'] if 'sentiment' in all_scam_reviews_df.columns else ['app_name', 'content', 'score', engagement_col]
    )

    columns_to_save = ['app_name', 'score', 'content', engagement_col, 'sentiment', 'is_scam'] if 'sentiment' in all_scam_reviews_df.columns else ['app_name', 'score', 'content', engagement_col, 'is_scam']

    export_path_2 = os.path.join(output_folder, "high_engagement_scam_review_contents.csv")
    high_engagement_reviews[high_engagement_reviews['is_scam']][columns_to_save].to_csv(export_path_2, index=False)

    print(f"\nSaved high engagement scam reviews to:\n- {export_path_1}\n- {export_path_2}")

else:
    print("No 'thumbsUp' or 'likes' column found in dataset. Please check your DataFrame.")
