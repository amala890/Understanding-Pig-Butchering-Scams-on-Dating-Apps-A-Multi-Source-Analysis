import pandas as pd


file_path = r"C:\\Users\\hp\\Desktop\\Results\\Result_GPS\\gpay_victimcount_original\\victim_reviews.csv"  



df = pd.read_csv(file_path)


app_counts = df['App Name'].value_counts().reset_index()


app_counts.columns = ['App Name', 'Review Count']


output_path = r"C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\app_name_review_counts.csv"
app_counts.to_csv(output_path, index=False)

print("App review counts saved to:", output_path)