import os
import pandas as pd
import re
from collections import defaultdict


scam_indicators = {
    "app_specific_complaints": [
        "app didn’t remove the scammer even after reports", "no way to verify accounts", 
        "scammers are not being flagged", "app is not doing enough to stop scams", 
        "reports not taken seriously", "scammers are not removed", "no scam detection system in place", 
        "no follow-up after reporting", "app does nothing about scammers", "ignored my report", 
        "no safety measures in place", "fraudulent accounts not flagged", "too many scammers on the platform", 
        "scam reports go unanswered", "reports get dismissed", "no actions taken on scam reports", 
        "app lacks proper monitoring", "scam detection is poor", "lack of action against scammer profiles", 
        "no mechanism to prevent scams", "fake profiles", "scammers are not filtered out",
        "unable to report scams", "app doesn't block scammers", "scammers on every profile", 
        "no way to identify fake profiles", "scammer problem is out of control", "app doesn't have security measures", 
        "profiles aren’t verified", "scam reports aren’t followed up", "scam report feature broken", 
        "no account verification system", "fake accounts run rampant", "verification doesn’t work", 
        "fake users are everywhere", "no way to confirm identity", "app not monitoring profiles", 
        "no verification checks", "fake messages from scammers", "scammer profile keeps popping up", 
        "scammers bypass security", "cannot report fake accounts", "no way to prevent scammer messages", 
        "fake profiles slip through"
    ],
    "suggestions_for_improved_safety": [
        "needs better verification", "should screen profiles better", "needs stricter account verification", 
        "app should require ID verification", "more robust account verification", "profile verification process should be improved", 
        "better protection against scammers", "implement background checks", "add two-factor authentication", 
        "more secure user verification", "add better security features", "increase profile verification methods", 
        "require more identity checks", "add face recognition for verification", "better ways to flag scammers", 
        "better moderation of profiles", "screen for fake profiles", "better privacy policies", "verification process needs to be stricter", 
        "screening process for users is weak", "more comprehensive safety checks", "app needs to improve security", 
        "better tools for identifying fake accounts", "stronger scam prevention tools",
        "more identity checks needed", "app needs to verify users", "require identity verification before chatting", 
        "implement face verification", "require government-issued ID", "need more user identity confirmation", 
        "profile screening should be more thorough", "needs manual review of profiles", "implement a scammer blacklist", 
        "better moderation for profiles", "verification should be more strict", "stronger profile verification methods", 
        "improve user safety features", "require selfie verification", "add real-time profile moderation", 
        "profile verification should be mandatory", "improve security to prevent scams", "use AI to detect fake profiles", 
        "add a flagging system for suspicious users"
    ]
}

def classify_review(text):
    text = text.lower()
    category_counts = defaultdict(int)
    
    for category, keywords in scam_indicators.items():
        for keyword in keywords:
            if re.search(r"\b" + re.escape(keyword) + r"\b", text):
                category_counts[category] += 1
    return category_counts

def process_reviews(folder_path):
    results = defaultdict(lambda: {category: 0 for category in scam_indicators})
    all_reviews = []

    print("Files detected in folder:", os.listdir(folder_path))

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            print(f"Processing: {file}")
            app_name = file.split('.')[0]
            file_path = os.path.join(folder_path, file)

            try:
                df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
            except Exception as e:
                print(f"Error reading {file}: {e}")
                continue

            if df.empty or "content" not in df.columns:
                print(f"Skipping {file} (empty or missing 'content')")
                continue

            for _, row in df.iterrows():
                review_text = str(row["content"]).lower()
                app_name_in_row = str(row.get("App", app_name)).strip()
                category_counts = classify_review(review_text)

                for category, count in category_counts.items():
                    results[app_name_in_row][category] += count

                if any(category_counts.values()):
                    all_reviews.append({
                        "app_name": app_name_in_row,
                        "review_text": review_text,
                        "scam_category": ", ".join([cat for cat, count in category_counts.items() if count > 0])
                    })

    return results, all_reviews

def save_results(results, all_reviews, output_folder):
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "app_name"}, inplace=True)

    summary_path = os.path.join(output_folder, "scam_indicators_summary.csv")
    classified_path = os.path.join(output_folder, "classified_scam_reviews.csv")

    summary_df.to_csv(summary_path, index=False)
    pd.DataFrame(all_reviews).to_csv(classified_path, index=False)

    print("Processing complete. Files saved at:")
    print(f"→ {summary_path}")
    print(f"→ {classified_path}")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\appspecifictrends_reviews"

results, all_reviews = process_reviews(folder_path)
save_results(results, all_reviews, output_folder)
