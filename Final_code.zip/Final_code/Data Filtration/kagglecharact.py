import os
import pandas as pd
from collections import defaultdict


scam_indicators = {
    
    "generic_pictures": ["generic photos", "stock images", "model-like pictures", "too perfect photos"],
    "living_abroad": ["living abroad", "working overseas", "based in another country", "expat"],
    "inconsistent_profiles": ["fake profile", "stolen photos", "catfish", "details don't match", "lied about age/job"],

    
    "pushing_investments": ["investments", "crypto", "trading", "side hustle", "send money"],
    "off_platform_moves": ["WhatsApp", "Telegram", "move to another app", "chat outside"],
    "avoiding_meetings": ["won't video call", "refused to meet", "excuses to not meet", "always traveling"]
    
}

def classify_review(text):
    text = text.lower()
    category_counts = defaultdict(int)
    
    for category, keywords in scam_indicators.items():
        for keyword in keywords:
            if keyword in text:
                category_counts[category] += 1
    
    return category_counts

def process_reviews(folder_path):
    results = defaultdict(lambda: {category: 0 for category in scam_indicators})
    all_reviews = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, encoding="ISO-8859-1")

            if "content" not in df.columns or "App" not in df.columns:
                print(f"Skipping {file} due to missing required columns.")
                continue

            for _, row in df.iterrows():
                App = str(row["App"]).strip()
                review_text = str(row["content"]).strip()
                category_counts = classify_review(review_text)

                for category, count in category_counts.items():
                    results[App][category] += count

                triggered = [cat for cat, count in category_counts.items() if count > 0]
                all_reviews.append([App, review_text, ", ".join(triggered)])

    return results, all_reviews


def save_results(results, all_reviews, output_folder):
    #
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)
    
    
    
    summary_df.to_csv(os.path.join(output_folder, "scam_indicators_summary.csv"), index=False)
    
    
    review_df = pd.DataFrame(all_reviews, columns=["App Name", "Review Content", "Scam Categories"])
    review_df.to_csv(os.path.join(output_folder, "classified_scam_reviews.csv"), index=False)
    
    print("Processing complete. Results saved.")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"  # Update with actual path
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\character_reviews"  # Update with actual path

results, all_reviews = process_reviews(folder_path)
save_results(results, all_reviews, output_folder)




