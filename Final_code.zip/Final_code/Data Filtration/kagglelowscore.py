import os
import pandas as pd


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\Lowscore_based_reviews"
os.makedirs(output_folder, exist_ok=True)


summary_data = []
low_score_reviews = []


for file in os.listdir(folder_path):
    if file.endswith(".csv"):
        file_path = os.path.join(folder_path, file)
        app_name = os.path.splitext(file)[0]

        try:
            df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            continue

        
        if "score" not in df.columns or "content" not in df.columns:
            print(f"Skipping {file}: Missing required columns.")
            continue

        df["score"] = pd.to_numeric(df["score"], errors="coerce")
        df = df.dropna(subset=["score"])
        
        score_1_count = (df["score"] == 1).sum()
        score_2_count = (df["score"] == 2).sum()
        score_above_3_count = (df["score"] > 3).sum()

        
        summary_data.append({
            "App Name": app_name,
            "Score 1 Count": score_1_count,
            "Score 2 Count": score_2_count,
            "Score >3 Count": score_above_3_count
        })

        
        low_scores = df[df["score"].isin([1, 2])][["score", "content"]].copy()
        low_scores["App Name"] = app_name
        low_score_reviews.append(low_scores)


summary_df = pd.DataFrame(summary_data)
summary_df.to_csv(os.path.join(output_folder, "score_summary_kaggle.csv"), index=False)


if low_score_reviews:
    all_low_score_df = pd.concat(low_score_reviews, ignore_index=True)
    all_low_score_df.rename(columns={"content": "Review Content"}, inplace=True)
    all_low_score_df.to_csv(os.path.join(output_folder, "low_score_reviews_kaggle.csv"), index=False)

print("Done: Summary and low-score reviews saved.")
