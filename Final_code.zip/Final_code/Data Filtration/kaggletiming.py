import os
import pandas as pd
from collections import defaultdict


timing_indicators = {
    "quick_escalation": [
        "within days", "suddenly asked", "out of nowhere",
        "started talking about money", "pivot to investments",
        "within a week", "few days later", "quickly changed"
    ],
    "delayed_escalation": [
        "after weeks", "months later", "gained trust first",
        "waited before asking"
    ]
}

def classify_timing(text):
    text = text.lower()
    result = {"quick_escalation": 0, "delayed_escalation": 0}

    for category, keywords in timing_indicators.items():
        for keyword in keywords:
            if keyword in text:
                result[category] += 1

    return result

def extract_app_name(file_name):
    return os.path.splitext(file_name)[0]

def process_timing_reviews(folder_path):
    summary = defaultdict(lambda: {"Quick Escalation": 0, "Delayed Escalation": 0, "No Mention": 0})
    all_classified_reviews = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, dtype=str, low_memory=False)

            if "content" not in df.columns or "userName" not in df.columns:
                print(f"Skipping {file} due to missing required columns.")
                continue

            app_name = extract_app_name(file)

            for _, row in df.iterrows():
                review_text = str(row["content"])
                user_name = row["userName"]
                timing_result = classify_timing(review_text)

                if timing_result["quick_escalation"] > 0:
                    category = "Quick Escalation"
                elif timing_result["delayed_escalation"] > 0:
                    category = "Delayed Escalation"
                else:
                    category = "No Mention"

                summary[app_name][category] += 1

                if category != "No Mention":
                    all_classified_reviews.append([app_name, user_name, review_text, category])

    return summary, all_classified_reviews

def save_timing_results(summary_dict, classified_reviews, output_folder):
    os.makedirs(output_folder, exist_ok=True)

    
    summary_df = pd.DataFrame.from_dict(summary_dict, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)

    
    total_row = {
        "App Name": "TOTAL",
        "Quick Escalation": summary_df["Quick Escalation"].sum(),
        "Delayed Escalation": summary_df["Delayed Escalation"].sum(),
        "No Mention": summary_df["No Mention"].sum()
    }
    summary_df = pd.concat([summary_df, pd.DataFrame([total_row])], ignore_index=True)

    summary_df.to_csv(os.path.join(output_folder, "timing_patterns_summary.csv"), index=False)

    # Save detailed classified reviews
    review_df = pd.DataFrame(classified_reviews, columns=["App Name", "User Name", "Review Content", "Timing Category"])
    review_df.to_csv(os.path.join(output_folder, "timing_classified_reviews.csv"), index=False)

    print("Timing patterns processed and saved.")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\timing_patterns"

summary_data, review_data = process_timing_reviews(folder_path)
save_timing_results(summary_data, review_data, output_folder)
