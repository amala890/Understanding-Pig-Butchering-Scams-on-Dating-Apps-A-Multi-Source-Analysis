import pandas as pd
import os
import re
from collections import defaultdict


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


app_trend_keywords = {
    "poor_detection": [
        "didn’t remove scammer", "ignored my report", "no action taken",
        "still seeing fake profiles", "scammers everywhere", "no moderation",
        "reported but still active", "no verification process",
        "fake accounts everywhere", "too many fake profiles", "fake profiles still active",
        "scammers not removed", "reporting doesn't help"
    ],
    "safety_suggestions": [
        "needs verification", "should screen profiles", "better moderation",
        "require ID check", "photo verification", "background checks",
        "ban suspicious accounts", "improve reporting", "protect users",
        "add safety features", "verify identity", "reporting tools need improvement"
    ]
}


def load_csv(filepath):
    try:
        return pd.read_csv(filepath)
    except UnicodeDecodeError:
        return pd.read_csv(filepath, encoding='ISO-8859-1')


df1 = load_csv(victim_reviews_file1)
df2 = load_csv(victim_reviews_file2)
combined_df = pd.concat([df1, df2], ignore_index=True)


combined_df["Review Content"] = combined_df["Review Content"].astype(str).fillna("")


compiled_patterns = {
    category: [re.compile(pattern, re.IGNORECASE) for pattern in patterns]
    for category, patterns in app_trend_keywords.items()
}


results = []
summary_counts = defaultdict(lambda: defaultdict(int))


for _, row in combined_df.iterrows():
    app_name = row["App Name"]
    user = row["User Name"]
    review = row["Review Content"]
    matched_categories = []

    for category, patterns in compiled_patterns.items():
        if any(pattern.search(review) for pattern in patterns):
            matched_categories.append(category)
            summary_counts[app_name][category] += 1

    if matched_categories:
        results.append({
            "App Name": app_name,
            "User Name": user,
            "Review Content": review,
            "Detected Trends": ", ".join(matched_categories)
        })


results_df = pd.DataFrame(results)
results_path = os.path.join(output_folder, "app_specific_trends_reviews.csv")
results_df.to_csv(results_path, index=False, encoding='utf-8-sig')


summary_data = []
for app, categories in summary_counts.items():
    row = {"App Name": app}
    row.update(categories)
    summary_data.append(row)

summary_df = pd.DataFrame(summary_data)
summary_path = os.path.join(output_folder, "app_specific_trends_summary.csv")
summary_df.to_csv(summary_path, index=False, encoding='utf-8-sig')

print("✅ App-specific trends extracted and saved successfully.")
