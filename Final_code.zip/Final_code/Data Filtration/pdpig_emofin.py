import pandas as pd
import os
import re

from collections import defaultdict


impact_keywords = {
    "financial_loss": [
        r"lost\s+\$?\d+[kK]?", r"invested\s+\$?\d+[kK]?", r"lost\s+money", r"scammed.*money",
        r"never\s+got\s+my\s+money\s+back", r"financial\s+ruin", r"drained\s+my\s+account",
        r"took\s+all\s+my\s+savings", r"conned\s+me\s+out\s+of\s+\$?\d+[kK]?", r"waste\s+money"
    ],
    "emotional_harm": [
        r"betrayed", r"heartbroken", r"felt\s+used", r"emotionally\s+devastated",
        r"manipulative", r"took\s+advantage\s+of\s+my\s+trust", r"destroyed\s+my\s+confidence",
        r"emotional\s+damage", r"left\s+me\s+in\s+tears", r"broke\s+my\s+heart", r"horrible", r"sad"
    ],
    "amounts": [
    r"\$\d{1,3}(?:,\d{3})*(?:\.\d{2})?",              
    r"\d{3,}(?:\.\d{2})?\s?(USD|usd|dollars)",        
    r"\d+[kK]",                                       
    r"\d{3,}(?:\.\d{2})?\s?(AED|aed|euros|EUR|eur)",  
    r"€\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?"             
]
}


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


try:
    df1 = pd.read_csv(victim_reviews_file1, encoding="utf-8-sig")
    df2 = pd.read_csv(victim_reviews_file2, encoding="utf-8-sig")
except UnicodeDecodeError:
    df1 = pd.read_csv(victim_reviews_file1, encoding="ISO-8859-1")
    df2 = pd.read_csv(victim_reviews_file2, encoding="ISO-8859-1")


combined_df = pd.concat([df1, df2], ignore_index=True)


impact_results = []
financial_loss_count = 0
emotional_harm_count = 0
total_money_mentions = []


for _, row in combined_df.iterrows():
    app = row["App Name"]
    user = row["User Name"]
    content = str(row["Review Content"]).lower()
    impacts_detected = []
    extracted_amounts = []

    
    if any(re.search(pattern, content) for pattern in impact_keywords["financial_loss"]):
        impacts_detected.append("Financial Loss")
        financial_loss_count += 1

    
    if any(re.search(pattern, content) for pattern in impact_keywords["emotional_harm"]):
        impacts_detected.append("Emotional Harm")
        emotional_harm_count += 1

    
    for amt_pattern in impact_keywords["amounts"]:
        matches = re.findall(amt_pattern, content, re.IGNORECASE)
        for m in matches:
            if isinstance(m, tuple):
                extracted_amounts.append(" ".join(m).strip())
            else:
                extracted_amounts.append(m.strip())
            total_money_mentions.append(m)

    
    if impacts_detected or extracted_amounts:
        impact_results.append({
            "App Name": app,
            "User Name": user,
            "Review Content": row["Review Content"],
            "Impacts Detected": "; ".join(set(impacts_detected)),
            "Mentioned Amounts": "; ".join(set(extracted_amounts))
        })


impact_df = pd.DataFrame(impact_results)
impact_df.to_csv(os.path.join(output_folder, "emotional_financial_impacts_reviews.csv"), index=False)


summary_data = {
    "Total Financial Loss Mentions": [financial_loss_count],
    "Total Emotional Harm Mentions": [emotional_harm_count],
    "Total Reviews Flagged": [len(impact_results)],
    "Total Amount Mentions Extracted": [len(total_money_mentions)],
    "Raw Amounts": [", ".join(total_money_mentions[:20])]  # Preview first 20
}
summary_df = pd.DataFrame(summary_data)
summary_df.to_csv(os.path.join(output_folder, "emotional_financial_impacts_summary.csv"), index=False)

print("✓ Emotional and Financial Impact analysis complete. Output files saved.")
