import pandas as pd
from collections import Counter
import re
from datetime import datetime
import os


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


os.makedirs(output_folder, exist_ok=True)


df1 = pd.read_csv(victim_reviews_file1, encoding='latin1')
df2 = pd.read_csv(victim_reviews_file2, encoding='latin1')



combined_df = pd.concat([df1, df2], ignore_index=True)


combined_df["Review Date"] = pd.to_datetime(combined_df["Review Date"], errors='coerce')
combined_df["Replied At"] = pd.to_datetime(combined_df["Replied At"], errors='coerce')


def classify_review_type(text):
    text = str(text).lower()
    if any(kw in text for kw in ["romance scam", "romance scammer", "we met on a dating app and"]):
        return "Romance Scam"
    elif any(kw in text for kw in ["crypto", "bitcoin", "investment scam", "trading scam", "pig butchering", "fake platform"]):
        return "Crypto Scam"
    elif any(kw in text for kw in ["money", "lost my savings", "financial scam", "wallet drained"]):
        return "Financial Scam"
    else:
        return "Other"


response_df = combined_df.dropna(subset=["Reply Content"]).copy()


response_df["Inferred Scam Type"] = response_df["Review Content"].apply(classify_review_type)


response_df["Response Time (days)"] = (response_df["Replied At"] - response_df["Review Date"]).dt.days
avg_response_time = response_df["Response Time (days)"].mean()


all_replies = " ".join(response_df["Reply Content"].astype(str)).lower()
common_phrases = Counter(re.findall(r'\b(thank you|sorry|contact us|support team|appreciate|feedback|email us|help|understand|resolve|inconvenience)\b', all_replies))


scam_type_counts = response_df["Inferred Scam Type"].value_counts()


summary = {
    "Total Reviews": len(combined_df),
    "Total Developer Responses": len(response_df),
    "Average Response Time (days)": round(avg_response_time, 2),
    "Most Common Phrases in Replies": dict(common_phrases),
    "Response Count by Inferred Scam Type": scam_type_counts.to_dict()
}


response_reviews_path = os.path.join(output_folder, "developer_replied_reviews.csv")
summary_path = os.path.join(output_folder, "developer_response_summary.csv")

response_df.to_csv(response_reviews_path, index=False)
pd.DataFrame([summary]).to_csv(summary_path, index=False)

print("✅ Developer responses analysis saved.")
