import pandas as pd
import os
from datetime import datetime
from collections import Counter
import re


victim_reviews_file = r"C:\Users\hp\Desktop\thu\victim_reviews_extra.csv"
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\gpay_count"


df = pd.read_csv(victim_reviews_file)


df['Replied At'] = pd.to_datetime(df['Replied At'], errors='coerce')
df['at'] = pd.to_datetime(df['at'], errors='coerce') if 'at' in df.columns else pd.NaT


replied_df = df[df['Reply Content'].notnull() & (df['Reply Content'].str.strip() != "")]


num_responses = replied_df.shape[0]
total_reviews = df.shape[0]


if 'at' in df.columns:
    replied_df = replied_df.copy()
    replied_df['response_time_days'] = (replied_df['Replied At'] - replied_df['at']).dt.days
    avg_response_time = replied_df['response_time_days'].mean()
else:
    avg_response_time = None


response_text = " ".join(replied_df['Reply Content'].dropna().astype(str).tolist()).lower()
common_phrases = Counter(re.findall(r'\b(thank you|sorry|contact us|support team|appreciate|feedback|email us|help|understand|resolve|inconvenience)\b', response_text))


def label_scam_type(text):
    text = str(text).lower()
    if any(k in text for k in ['crypto', 'bitcoin', 'investment']):
        return 'Crypto Scam'
    elif any(k in text for k in ['love', 'romance', 'boyfriend', 'girlfriend']):
        return 'Romance Scam'
    elif any(k in text for k in ['money', 'loan', 'refund', 'charged']):
        return 'Financial Scam'
    else:
        return 'Other/Unknown'

replied_df['Scam Type (inferred)'] = replied_df['Review Content'].apply(label_scam_type)
scam_type_counts = replied_df['Scam Type (inferred)'].value_counts()


summary = {
    "Total Reviews": total_reviews,
    "Total Developer Responses": num_responses,
    "Average Response Time (days)": avg_response_time,
    "Most Common Phrases in Replies": dict(common_phrases),
    "Response Count by Inferred Scam Type": scam_type_counts.to_dict()
}


summary_df = pd.DataFrame(list(summary.items()), columns=["Metric", "Value"])
summary_path = os.path.join(output_folder, "developer_response_summary.csv")
summary_df.to_csv(summary_path, index=False)


detailed_output_path = os.path.join(output_folder, "developer_response_detailed.csv")
replied_df.to_csv(detailed_output_path, index=False)

print("Developer response analysis complete. Results saved.")

