import pandas as pd
import re
import os


victim_reviews_file = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


def classify_review_type(text):
    text = text.lower()
    if any(kw in text for kw in ["romance scam", "romance scammer", "we met on a dating app and"]):
        return "Romance Scam"
    elif any(kw in text for kw in ["crypto", "bitcoin", "investment scam", "trading scam", "pig butchering", "fake platform"]):
        return "Crypto Scam"
    elif any(kw in text for kw in ["money", "lost my savings", "financial scam", "wallet drained"]):
        return "Financial Scam"
    else:
        return "Other"


df = pd.read_csv(victim_reviews_file)


df['ThumbsUp'] = pd.to_numeric(df['ThumbsUp'], errors='coerce')


high_thumbs_df = df[df['ThumbsUp'] > 20].copy()


high_thumbs_df['Review Type'] = high_thumbs_df['Review Content'].apply(classify_review_type)


output_reviews_path = os.path.join(output_folder, "high_thumbsup_reviews.csv")
high_thumbs_df.to_csv(output_reviews_path, index=False)


summary = {
    "Total High ThumbsUp Reviews (>20)": len(high_thumbs_df),
    "Review Type Breakdown": high_thumbs_df["Review Type"].value_counts().to_dict()
}


summary_path = os.path.join(output_folder, "high_thumbsup_summary.txt")
with open(summary_path, "w", encoding='utf-8') as f:
    f.write("=== High ThumbsUp Review Summary ===\n")
    f.write(f"Total Reviews with ThumbsUp > 20: {summary['Total High ThumbsUp Reviews (>20)']}\n\n")
    f.write("=== Review Type Breakdown ===\n")
    for scam_type, count in summary["Review Type Breakdown"].items():
        f.write(f"{scam_type}: {count}\n")

print("✅ High ThumbsUp analysis complete. CSV and summary saved.")
