import pandas as pd
import re
import os


input_file = r"C:\Users\hp\Desktop\thu\victim_reviews.csv"
output_file = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\gpay_count\app_specific_trends_results.csv"


df = pd.read_csv(input_file, encoding='ISO-8859-1', quotechar='"', skipinitialspace=True)



app_trend_keywords = {
    "poor_detection": [
        "didn’t remove scammer", "ignored my report", "no action taken",
        "still seeing fake profiles", "scammers everywhere", "no moderation",
        "reported but still active", "no verification process",
        "fake accounts everywhere", "too many fake profiles", "fake profiles still active",
        "scammers not removed", "reporting doesn't help"
    ],
    "safety_suggestions": [
        "needs verification", "should screen profiles", "better moderation",
        "require ID check", "photo verification", "background checks",
        "ban suspicious accounts", "improve reporting", "protect users",
        "add safety features", "verify identity", "reporting tools need improvement"
    ]
}


def detect_trends(review):
    matches = []
    for category, patterns in app_trend_keywords.items():
        for pattern in patterns:
            if re.search(re.escape(pattern), str(review), flags=re.IGNORECASE):
                matches.append(category)
                break  
    return ",".join(set(matches)) if matches else None


df["Detected_Trends"] = df["Review Content"].apply(detect_trends)


matched_df = df[df["Detected_Trends"].notna()].copy()

matched_df.to_csv(output_file, index=False)


summary_counts = matched_df["Detected_Trends"].str.get_dummies(sep=",").sum()
print("Summary of Detected Trends:")
print(summary_counts)
