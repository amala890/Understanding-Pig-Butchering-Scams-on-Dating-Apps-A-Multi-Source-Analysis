import pandas as pd
import re
from collections import defaultdict
import os


characteristics_patterns = {
    "Generic Profile Picture": [
        "too good looking", "very attractive", "model looking", "stock photo", "fake profile picture"
    ],
    "Claims of Living Abroad": [
        "lives abroad", "working overseas", "from another country", "moved to [a-z]+", "he said he's in [a-z]+", "she's in dubai", "currently in [a-z]+"
    ],
    "Inconsistent Profile Information": [
        "profile didn’t match", "inconsistent details", "info didn’t add up", "profile said one thing", "different name"
    ],
    "Pushing Investment Opportunities": [
        "asked me to invest", "told me about crypto", "investment opportunity", "financial freedom", "join his trading", "crypto scheme", "persistent about investing", "bitcoin investment", "she kept promoting"
    ],
    "Shifting to Off-Platform Channels": [
        "move to whatsapp", "talk on telegram", "switch to line", "add me on signal", "we left the app", "asked for my number"
    ],
    "Avoiding Video/In-Person Meetings": [
        "refused video call", "never met", "avoided face to face", "excuses for not meeting", "didn’t want to video chat", "always busy to meet", "said camera is broken"
    ]
}

def classify_characteristics(text):
    text = text.lower()
    found_tags = []

    for label, patterns in characteristics_patterns.items():
        for pattern in patterns:
            if re.search(pattern, text):
                found_tags.append(label)
                break  

    return found_tags

def process_victim_reviews(file_path, output_folder):
    df = pd.read_csv(file_path, encoding='ISO-8859-1')  


    if "Review Content" not in df.columns:
        raise ValueError("Missing 'Review Content' column.")

    
    tags_list = []
    counts = defaultdict(int)
    tagged_reviews = []

    for _, row in df.iterrows():
        text = str(row["Review Content"])
        tags = classify_characteristics(text)
        tags_list.append(", ".join(tags))

        if tags:
            for tag in tags:
                counts[tag] += 1
            tagged_reviews.append([row["App Name"], row["User Name"], text, ", ".join(tags)])

    df["Behavioral Tags"] = tags_list

    os.makedirs(output_folder, exist_ok=True)
    
    
    tagged_output = os.path.join(output_folder, "victim_reviews_with_tags.csv")
    df.to_csv(tagged_output, index=False)

    
    tagged_only_df = pd.DataFrame(tagged_reviews, columns=["App Name", "User Name", "Review Content", "Behavioral Tags"])
    tagged_only_df.to_csv(os.path.join(output_folder, "behavioral_reviews_only.csv"), index=False)

   
    summary_df = pd.DataFrame(counts.items(), columns=["Behavioral Characteristic", "Count"])
    summary_df.to_csv(os.path.join(output_folder, "behavioral_characteristics_summary.csv"), index=False)

    print("✅ Done. Outputs saved in:", output_folder)


victim_reviews_file = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"

process_victim_reviews(victim_reviews_file, output_folder)
