import pandas as pd
import re
import os


victim_reviews_file = r"C:\Users\hp\Desktop\thu\victim_reviews.csv"
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\gpay_count"
output_file = os.path.join(output_folder, "emotional_financial_impacts.csv")


df = pd.read_csv(victim_reviews_file, encoding="ISO-8859-1", on_bad_lines='skip')  # Adjust encoding if needed
df = df.dropna(subset=["Review Content"])


impact_keywords = {
    "financial_loss": [
        r"lost\s+\$?\d+[kK]?", r"invested\s+\$?\d+[kK]?", r"lost\s+money", r"scammed.*money",
        r"never\s+got\s+my\s+money\s+back", r"financial\s+ruin", r"drained\s+my\s+account",
        r"took\s+all\s+my\s+savings", r"conned\s+me\s+out\s+of\s+\$?\d+[kK]?"
    ],
    "emotional_harm": [
        r"betrayed", r"heartbroken", r"felt\s+used", r"emotionally\s+devastated",
        r"manipulative", r"took\s+advantage\s+of\s+my\s+trust", r"destroyed\s+my\s+confidence",
        r"emotional\s+damage", r"left\s+me\s+in\s+tears", r"broke\s+my\s+heart"
    ],
    "amounts": [
        r"\$\d{1,3}(?:,\d{3})*(?:\.\d{2})?",  
        r"\d{3,}(?:\.\d{2})?\s?(USD|usd|dollars)",  
        
    ]
}


results = []
for _, row in df.iterrows():
    review = str(row["Review Content"]).lower()
    app = row["App Name"]
    username = row["User Name"]

    matched_types = []
    matched_keywords = []

    for key, patterns in impact_keywords.items():
        for pattern in patterns:
            matches = re.findall(pattern, review)
            if matches:
                matched_types.append(key)
                matched_keywords.extend(matches)

    if matched_types:
        results.append({
            "App Name": app,
            "User Name": username,
            "Review Content": review,
            "Impact Type": ", ".join(set(matched_types)),
            "Matched Keywords": ", ".join(set(matched_keywords))
        })


if results:
    result_df = pd.DataFrame(results)
    result_df.to_csv(output_file, index=False, encoding="utf-8")
    print(f"✅ Extracted {len(result_df)} impactful reviews saved to:\n{output_file}")
else:
    print("⚠️ No emotional or financial impact patterns found in the reviews.")
