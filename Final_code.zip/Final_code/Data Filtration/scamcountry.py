import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


file_path = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv'
df = pd.read_csv(file_path)


output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smp'
os.makedirs(output_folder, exist_ok=True)


def extract_country(text):
    countries = {
        'US': ['usa', 'united states', 'america', 'u.s.', 'new york', 'california'],
        'UK': ['uk', 'united kingdom', 'england', 'london', 'britain'],
        'Canada': ['canada', 'toronto', 'vancouver'],
        'Australia': ['australia', 'sydney', 'melbourne'],
        'China': ['china', 'hong kong', 'beijing', 'shanghai'],
        'India': ['india', 'delhi', 'mumbai', 'bangalore']
    }
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    for country, keywords in countries.items():
        if any(keyword in text for keyword in keywords):
            return country
    return 'other'


df['country'] = df['content'].apply(extract_country)


def extract_app(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    if 'tinder' in text:
        return 'tinder'
    elif 'match' in text or 'match.com' in text:
        return 'match'
    elif 'hinge' in text:
        return 'hinge'
    else:
        return 'other'

if 'app_mentioned' not in df.columns:
    df['app_mentioned'] = df['content'].apply(extract_app)


df[['content', 'platform', 'app_mentioned', 'country']].to_csv(
    os.path.join(output_folder, 'scam_reviews_with_countries.csv'), index=False, encoding='utf-8'
)
print("✅ Saved: scam_reviews_with_countries.csv")


country_counts = df['country'].value_counts()
country_counts.to_csv(os.path.join(output_folder, 'scam_country_counts.csv'))
print("✅ Saved: scam_country_counts.csv")


plt.figure(figsize=(8, 6))
sns.barplot(x=country_counts.index, y=country_counts.values, palette='Accent')
plt.title('Country Mentions in Scam-Related Posts')
plt.ylabel('Count')
plt.xlabel('Country')
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_country_bar_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_country_bar_chart.png")


country_by_app = df.groupby(['app_mentioned', 'country']).size().unstack().fillna(0)
country_by_app.to_csv(os.path.join(output_folder, 'scam_countries_by_app.csv'))
print("✅ Saved: scam_countries_by_app.csv")


plt.figure(figsize=(12, 7))
ax = country_by_app.plot(kind='bar', colormap='cubehelix', edgecolor='black')
plt.title('Country Mentions by Dating App')
plt.xlabel('Dating App')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Country', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_countries_by_app_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_countries_by_app_chart.png")


country_by_platform = df.groupby(['platform', 'country']).size().unstack().fillna(0)
country_by_platform.to_csv(os.path.join(output_folder, 'scam_countries_by_platform.csv'))
print("✅ Saved: scam_countries_by_platform.csv")


plt.figure(figsize=(12, 7))
ax = country_by_platform.plot(kind='bar', colormap='tab20', edgecolor='black')
plt.title('Country Mentions by Platform')
plt.xlabel('Platform')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Country', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_countries_by_platform_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_countries_by_platform_chart.png")
