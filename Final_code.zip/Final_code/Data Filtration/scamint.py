import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


file_path = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv'
df = pd.read_csv(file_path)


output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps'
os.makedirs(output_folder, exist_ok=True)


def extract_duration(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()

    short = ['few days', 'couple of days', '2 days', '3 days', '4 days', '5 days', 'less than a week', 'a week']
    medium = ['2 weeks', 'three weeks', '3 weeks', 'four weeks', 'a few weeks', 'couple of weeks']
    long = ['a month', '1 month', '2 months', 'three months', 'few months', 'over a month']

    if any(phrase in text for phrase in short):
        return '<1 week'
    elif any(phrase in text for phrase in medium):
        return '1-4 weeks'
    elif any(phrase in text for phrase in long):
        return '1+ months'
    else:
        return 'unknown'


df['duration'] = df['content'].apply(extract_duration)


def extract_app(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    if 'tinder' in text:
        return 'tinder'
    elif 'match' in text:
        return 'match'
    elif 'hinge' in text:
        return 'hinge'
    else:
        return 'other'

if 'app_mentioned' not in df.columns:
    df['app_mentioned'] = df['content'].apply(extract_app)


df[['content', 'platform', 'app_mentioned', 'duration']].to_csv(
    os.path.join(output_folder, 'scam_reviews_with_duration.csv'), index=False, encoding='utf-8'
)
print("✅ Saved: scam_reviews_with_duration.csv")


duration_counts = df['duration'].value_counts().reindex(['<1 week', '1-4 weeks', '1+ months', 'unknown'])
duration_counts.to_csv(os.path.join(output_folder, 'duration_counts.csv'))
print("✅ Saved: duration_counts.csv")


plt.figure(figsize=(8, 6))
sns.barplot(x=duration_counts.index, y=duration_counts.values, palette='Blues_d')
plt.title('Duration of Interaction in Scam-Related Posts')
plt.ylabel('Count')
plt.xlabel('Duration')
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'duration_distribution_bar_chart.png'), dpi=300)
plt.close()
print("✅ Saved: duration_distribution_bar_chart.png")


duration_by_app = df.groupby(['app_mentioned', 'duration']).size().unstack().fillna(0)
duration_by_app.to_csv(os.path.join(output_folder, 'duration_by_app.csv'))
print("✅ Saved: duration_by_app.csv")


plt.figure(figsize=(10, 6))
ax = duration_by_app.plot(kind='bar', colormap='coolwarm', edgecolor='black')
plt.title('Duration of Interaction by Dating App')
plt.xlabel('App')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Duration', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'duration_by_app_chart.png'), dpi=300)
plt.close()
print("✅ Saved: duration_by_app_chart.png")


duration_by_platform = df.groupby(['platform', 'duration']).size().unstack().fillna(0)
duration_by_platform.to_csv(os.path.join(output_folder, 'duration_by_platform.csv'))
print("✅ Saved: duration_by_platform.csv")


plt.figure(figsize=(10, 6))
ax = duration_by_platform.plot(kind='bar', colormap='viridis', edgecolor='black')
plt.title('Duration of Interaction by Platform')
plt.xlabel('Platform')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Duration', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'duration_by_platform_chart.png'), dpi=300)
plt.close()
print("✅ Saved: duration_by_platform_chart.png")
