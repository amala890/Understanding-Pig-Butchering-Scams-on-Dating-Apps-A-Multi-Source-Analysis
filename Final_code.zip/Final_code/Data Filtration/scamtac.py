import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


file_path = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv'
df = pd.read_csv(file_path)


output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps'
os.makedirs(output_folder, exist_ok=True)

tactics = {
    'investment': ['invest', 'crypto', 'bitcoin', 'stock', 'return', 'profit'],
    'emergency': ['emergency', 'help', 'urgent', 'need money', 'hospital'],
    'gift': ['gift', 'present', 'package', 'customs', 'fee'],
    'other': []
}


def extract_scam_tactic(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    for tactic, keywords in tactics.items():
        if any(keyword in text for keyword in keywords):
            return tactic
    return 'other'

df['scam_tactic'] = df['content'].apply(extract_scam_tactic)


def extract_app(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    if 'tinder' in text:
        return 'tinder'
    elif 'match' in text or 'match.com' in text:
        return 'match'
    elif 'hinge' in text:
        return 'hinge'
    else:
        return 'other'

if 'app_mentioned' not in df.columns:
    df['app_mentioned'] = df['content'].apply(extract_app)


df[['content', 'platform', 'app_mentioned', 'scam_tactic']].to_csv(
    os.path.join(output_folder, 'scam_reviews_with_tactics.csv'), index=False, encoding='utf-8'
)
print("✅ Saved: scam_reviews_with_tactics.csv")


tactic_counts = df['scam_tactic'].value_counts()
tactic_counts.to_csv(os.path.join(output_folder, 'scam_tactic_counts.csv'))
print("✅ Saved: scam_tactic_counts.csv")


plt.figure(figsize=(8, 6))
sns.barplot(x=tactic_counts.index, y=tactic_counts.values, palette='Set2')
plt.title('Scam Tactics Overall')
plt.ylabel('Count')
plt.xlabel('Scam Tactic')
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_tactic_bar_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_tactic_bar_chart.png")


tactic_by_app = df.groupby(['app_mentioned', 'scam_tactic']).size().unstack().fillna(0)
tactic_by_app.to_csv(os.path.join(output_folder, 'scam_tactics_by_app.csv'))
print("✅ Saved: scam_tactics_by_app.csv")


plt.figure(figsize=(12, 7))
ax = tactic_by_app.plot(kind='bar', colormap='viridis', edgecolor='black')
plt.title('Scam Tactics by Dating App')
plt.xlabel('Dating App')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Tactic', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_tactics_by_app_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_tactics_by_app_chart.png")


tactic_by_platform = df.groupby(['platform', 'scam_tactic']).size().unstack().fillna(0)
tactic_by_platform.to_csv(os.path.join(output_folder, 'scam_tactics_by_platform.csv'))
print("✅ Saved: scam_tactics_by_platform.csv")


plt.figure(figsize=(12, 7))
ax = tactic_by_platform.plot(kind='bar', colormap='tab10', edgecolor='black')
plt.title('Scam Tactics by Platform')
plt.xlabel('Platform')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Tactic', bbox_to_anchor=(1.05, 1), loc='upper left')
for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=8)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'scam_tactics_by_platform_chart.png'), dpi=300)
plt.close()
print("✅ Saved: scam_tactics_by_platform_chart.png")
