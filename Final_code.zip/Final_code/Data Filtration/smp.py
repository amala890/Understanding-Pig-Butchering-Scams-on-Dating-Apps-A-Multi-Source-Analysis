import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from collections import Counter
import re


input_folders = {
    "Reddit": {
        "path": r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Reddit",
        "content_column": "Content"
    },
    "Instagram": {
        "path": r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Instagram",
        "content_column": "caption"
    },
    "Twitter": {
        "path": r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Twitter",
        "content_column": "text"
    }
}

output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result_smp"
os.makedirs(output_folder, exist_ok=True)


dfs = []
for platform, info in input_folders.items():
    folder = info['path']
    content_col = info['content_column']

    print(f"\n🔍 Reading {platform} from: {folder}")
    if not os.path.exists(folder):
        print(f"❌ Missing folder: {folder}")
        continue

    files = [f for f in os.listdir(folder) if f.endswith('.csv')]
    if not files:
        print(f"⚠️ No CSVs found in: {folder}")
        continue

    for file in files:
        path = os.path.join(folder, file)
        try:
            df = pd.read_csv(path)
            if content_col not in df.columns:
                print(f"⚠️ '{content_col}' not in {file}")
                continue
            df = df.rename(columns={content_col: 'content'})
            df = df.dropna(subset=['content'])
            df['content'] = df['content'].astype(str).str.lower()
            df['platform'] = platform
            dfs.append(df[['content', 'platform']])
            print(f"✅ Loaded {file} ({len(df)} rows)")
        except Exception as e:
            print(f"❌ Failed {file}: {e}")


if not dfs:
    raise ValueError("🚫 No valid data found.")
combined_df = pd.concat(dfs, ignore_index=True)
print(f"\n✅ Combined total: {len(combined_df)} posts")


scam_keywords = [
    "investment", "crypto", "bitcoin", "trading", "profits", "returns", "money",
    "financial advisor", "business opportunity", "forex", "stock market", "wealth",
    "passive income", "get rich quick", "high returns", "low risk", "financial freedom",
    "cryptocurrency", "blockchain", "wallet address", "send money", "bank transfer",
    "payment", "funds", "scam", "fraud", "fake", "cheat", "swindle", "con artist",
    "scammer", "scamming", "scammed", "trust", "love", "relationship", "romance",
    "emotional", "manipulation", "soulmate", "marriage", "commitment", "future together",
    "true love", "heartbroken", "broken trust", "lied to", "deceived", "betrayed",
    "fake love", "pretend", "emotional scam", "romance scam", "catfish", "fake profile",
    "fake identity", "fake person", "fake account", "too good to be true", "frequent traveler",
    "living abroad", "avoid meeting", "external app", "whatsapp", "telegram", "skype",
    "line", "wechat", "move to another app", "private chat", "secretive", "no video call",
    "no phone call", "no meetup", "avoid in-person", "long distance", "military",
    "engineer", "doctor", "oil rig", "working overseas", "urgent", "emergency",
    "need money", "financial help", "help me", "desperate", "quick money", "urgent request",
    "urgent need", "urgent help", "urgent situation", "no moderation", "no support",
    "reported but no action", "bot accounts", "spam accounts", "hacked", "privacy concerns",
    "data breach", "phishing", "malware", "virus", "untrustworthy", "unreliable",
    "no customer service", "ignored reports", "ignored complaints"
]

pattern = '|'.join(re.escape(word) for word in scam_keywords)
combined_df['is_scam_related'] = combined_df['content'].str.contains(pattern, na=False)


scam_count = combined_df['is_scam_related'].sum()
total = len(combined_df)
print(f"\n🔎 Scam mentions: {scam_count} out of {total} posts ({scam_count / total * 100:.1f}%)")


scam_text = ' '.join(combined_df[combined_df['is_scam_related']]['content'])
wordcloud = WordCloud(width=1000, height=500, background_color='white').generate(scam_text)

plt.figure(figsize=(14, 7))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title("Word Cloud of Scam-Related Posts", fontsize=16)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "scam_wordcloud.png"))
plt.show()


words = re.findall(r'\b\w+\b', scam_text)
word_counts = Counter(words)
stopwords = set(['the', 'and', 'to', 'a', 'is', 'in', 'of', 'for', 'on', 'at', 'i', 'with', 'it'])
top_keywords = [(word, count) for word, count in word_counts.items() if word not in stopwords]
top_keywords = sorted(top_keywords, key=lambda x: x[1], reverse=True)[:20]


words, counts = zip(*top_keywords)
plt.figure(figsize=(12, 6))
sns.barplot(x=list(counts), y=list(words), palette='magma')
plt.title("Top Keywords in Scam-Related Posts")
plt.xlabel("Frequency")
plt.ylabel("Keyword")
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "scam_keywords_barplot.png"))
plt.show()


platform_stats = combined_df.groupby('platform')['is_scam_related'].mean().sort_values(ascending=False) * 100

plt.figure(figsize=(10, 5))
sns.barplot(x=platform_stats.index, y=platform_stats.values, palette='coolwarm')
plt.ylabel("Scam-Related Posts (%)")
plt.title("Scam Frequency by Platform")
plt.ylim(0, 100)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "scam_by_platform.png"))
plt.show()


output_file = os.path.join(output_folder, "scam_related_social_posts.csv")
combined_df[combined_df['is_scam_related']].to_csv(output_file, index=False)
print(f"\n💾 Saved {scam_count} scam-related posts to: {output_file}")
