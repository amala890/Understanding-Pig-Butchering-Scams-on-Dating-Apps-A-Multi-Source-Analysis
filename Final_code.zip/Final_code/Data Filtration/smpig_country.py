import pandas as pd
import os
import re


countries = {
    'US': ['usa', 'united states', 'america', 'u.s.', 'new york', 'california'],
    'UK': ['uk', 'united kingdom', 'england', 'london', 'britain'],
    'Canada': ['canada', 'toronto', 'vancouver'],
    'Australia': ['australia', 'sydney', 'melbourne'],
    'China': ['china', 'hong kong', 'beijing', 'shanghai'],
    'India': ['india', 'delhi', 'mumbai', 'bangalore'],
    'Germany': ['germany', 'berlin', 'munich', 'frankfurt'],
    'UAE': ['uae', 'dubai', 'abu dhabi'],
    'Philippines': ['philippines', 'manila', 'cebu'],
    'Singapore': ['singapore'],
    'Nigeria': ['nigeria', 'lagos', 'abuja'],
    'Russia': ['russia', 'moscow', 'saint petersburg'],
    'France': ['france', 'paris', 'lyon'],
    'Italy': ['italy', 'rome', 'milan'],
    'Thailand': ['thailand', 'bangkok', 'phuket'],
    'South Korea': ['south korea', 'seoul'],
    'Japan': ['japan', 'tokyo', 'osaka']
}



instagram_file = "C:\\Users\\hp\\Desktop\\thu\\instagram_filtered_victim_reviews.csv"
reddit_file = "C:\\Users\\hp\\Desktop\\thu\\reddit_scam_reviews.csv"
twitter_file = "C:\\Users\\hp\\Desktop\\thu\\twitter_scam_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count"
os.makedirs(output_folder, exist_ok=True)


def detect_country(text):
    text = text.lower()
    matched = []
    for country, keywords in countries.items():
        for kw in keywords:
            if re.search(r'\b' + re.escape(kw) + r'\b', text):
                matched.append(country)
                break
    return matched if matched else ['Unknown']


df_insta = pd.read_csv(instagram_file)
df_insta['Platform'] = 'Instagram'
df_insta['Text'] = df_insta['Caption'].astype(str)
df_insta['Country'] = df_insta['Text'].apply(detect_country)


df_reddit = pd.read_csv(reddit_file)
df_reddit['Platform'] = 'Reddit'
df_reddit['Text'] = df_reddit['Post Content'].astype(str)
df_reddit['Country'] = df_reddit['Text'].apply(detect_country)


df_twitter = pd.read_csv(twitter_file)
df_twitter['Platform'] = 'Twitter'
df_twitter['Text'] = df_twitter['Tweet Text'].astype(str)
df_twitter['Country'] = df_twitter['Text'].apply(detect_country)


all_data = pd.concat([df_insta, df_reddit, df_twitter], ignore_index=True)
all_data['App Name'] = all_data['App name'].fillna('Nil')


exploded = all_data.explode('Country')


exploded.to_csv(os.path.join(output_folder, "country_tagged_reviews.csv"), index=False)


summary_by_app = exploded.groupby(['App Name', 'Country']).size().unstack(fill_value=0)
summary_by_app.to_csv(os.path.join(output_folder, "country_summary_by_app.csv"))


summary_by_platform = exploded.groupby(['Platform', 'Country']).size().unstack(fill_value=0)
summary_by_platform.to_csv(os.path.join(output_folder, "country_summary_by_platform.csv"))

print("✅ Country detection completed and files saved.")
