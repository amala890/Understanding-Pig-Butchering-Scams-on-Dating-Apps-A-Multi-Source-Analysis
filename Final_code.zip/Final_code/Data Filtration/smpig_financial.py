import pandas as pd
import os
import re

# Define patterns
financial_loss_patterns = [
    r"lost\s+\$?\d+[kK]?", r"invested\s+\$?\d+[kK]?", r"lost\s+money", r"scammed.*money",
    r"never\s+got\s+my\s+money\s+back", r"financial\s+ruin", r"drained\s+my\s+account",
    r"took\s+all\s+my\s+savings", r"conned\s+me\s+out\s+of\s+\$?\d+[kK]?", r"waste\s+money"
]

amount_patterns = [
    r"\$\d{1,3}(?:,\d{3})*(?:\.\d{2})?",              
    r"\d{3,}(?:\.\d{2})?\s?(USD|usd|dollars)",        
    r"\d+[kK]",                                       
    r"\d{3,}(?:\.\d{2})?\s?(AED|aed|euros|EUR|eur)",  
    r"€\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?"            
]


def match_patterns(text, patterns):
    text = str(text).lower()
    return any(re.search(p, text) for p in patterns)

def extract_amounts(text, patterns):
    text = str(text)
    amounts = []
    for p in patterns:
        found = re.findall(p, text)
        if found:
            amounts.extend(found)
    return ', '.join(map(str, amounts)) if amounts else None

instagram_file = "C:\\Users\\hp\\Desktop\\thu\\instagram_filtered_victim_reviews.csv"
reddit_file = "C:\\Users\\hp\\Desktop\\thu\\reddit_scam_reviews.csv"
twitter_file = "C:\\Users\\hp\\Desktop\\thu\\twitter_scam_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count"

os.makedirs(output_folder, exist_ok=True)


reddit_df = pd.read_csv(reddit_file)
reddit_df['Source'] = 'Reddit'
reddit_df['Text'] = reddit_df['Post Content']
reddit_df['App Name'] = reddit_df.get('App name', None)
reddit_df['Loss_Flag'] = reddit_df['Text'].apply(lambda x: match_patterns(x, financial_loss_patterns))
reddit_df['Amount_Mentioned'] = reddit_df['Text'].apply(lambda x: extract_amounts(x, amount_patterns))


insta_df = pd.read_csv(instagram_file)
insta_df['Source'] = 'Instagram'
insta_df['Text'] = insta_df['Caption']
insta_df['App Name'] = insta_df.get('App name', None)
insta_df['Loss_Flag'] = insta_df['Text'].apply(lambda x: match_patterns(x, financial_loss_patterns))
insta_df['Amount_Mentioned'] = insta_df['Text'].apply(lambda x: extract_amounts(x, amount_patterns))


twitter_df = pd.read_csv(twitter_file)
twitter_df['Source'] = 'Twitter'
twitter_df['Text'] = twitter_df['Tweet Text']
twitter_df['App Name'] = twitter_df.get('App Name', None)
twitter_df['Loss_Flag'] = twitter_df['Text'].apply(lambda x: match_patterns(x, financial_loss_patterns))
twitter_df['Amount_Mentioned'] = twitter_df['Text'].apply(lambda x: extract_amounts(x, amount_patterns))


combined_df = pd.concat([reddit_df, insta_df, twitter_df], ignore_index=True)
loss_df = combined_df[combined_df['Loss_Flag'] == True]



detailed_output = os.path.join(output_folder, "financial_loss_reviews.csv")
loss_df.to_csv(detailed_output, index=False)


summary = loss_df.groupby('Source').size().reset_index(name='Financial_Loss_Review_Count')
summary_output = os.path.join(output_folder, "financial_loss_summary.csv")
summary.to_csv(summary_output, index=False)

if 'App Name' in loss_df.columns:
    summary_app = loss_df.groupby('App Name').size().reset_index(name='Loss_Flag_Review_Count')
    summary_app.to_csv(os.path.join(output_folder, "financial_loss_summary_by_app.csv"), index=False)



print("✅ Done. Financial loss data saved to:")
print(f"  → financial_loss_reviews.csv")
print(f"  → financial_loss_summary_by_platform.csv")
print(f"  → financial_loss_summary_by_app.csv")
