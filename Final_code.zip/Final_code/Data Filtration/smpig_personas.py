import os
import pandas as pd
import re


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\instagram_filtered_victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\reddit_scam_reviews.csv"
victim_reviews_file3 = "C:\\Users\\hp\\Desktop\\thu\\twitter_scam_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count"


personas = {
    'businessman': ['businessman', 'entrepreneur', 'executive', 'ceo', 'investor', 'founder', 'startup', 'company owner'],
    'military': ['military', 'army', 'navy', 'air force', 'soldier', 'marine', 'commander', 'sergeant'],
    'medical': ['doctor', 'nurse', 'surgeon', 'physician'],
    'engineer': ['engineer', 'software engineer', 'software developer', 'civil engineer', 'mechanical engineer', 'it engineer'],
    'pilot': ['pilot', 'aviator', 'airline captain', 'flight commander'],
    'lawyer': ['lawyer', 'attorney', 'legal advisor'],
    'oil_worker': ['oil rig', 'oil engineer', 'offshore', 'petroleum'],
    'wealthy': ['millionaire', 'rich', 'wealthy', 'luxury', 'affluent', 'high net worth', 'financially independent', 'moneyed', 'successful'],
    'crypto_trader': ['bitcoin', 'crypto', 'cryptocurrency', 'blockchain', 'trader', 'forex', 'investment opportunity']
}



compiled_personas = {
    category: [re.compile(r'\b' + re.escape(word.lower()) + r'\b') for word in keywords]
    for category, keywords in personas.items() if keywords
}


def detect_persona(text):
    text = text.lower()
    for category, patterns in compiled_personas.items():
        for pattern in patterns:
            if pattern.search(text):
                return category
    return 'other'


all_reviews = []


df1 = pd.read_csv(victim_reviews_file1)
for _, row in df1.iterrows():
    caption = str(row.get("Caption", ""))
    app = row.get("App name", "Nil")
    persona = detect_persona(caption)
    all_reviews.append({
        "Platform": "Instagram",
        "Text": caption,
        "App name": app,
        "Persona": persona
    })


df2 = pd.read_csv(victim_reviews_file2)
for _, row in df2.iterrows():
    post = str(row.get("Post Content", ""))
    app = row.get("App name", "Nil")
    persona = detect_persona(post)
    all_reviews.append({
        "Platform": "Reddit",
        "Text": post,
        "App name": app,
        "Persona": persona
    })


df3 = pd.read_csv(victim_reviews_file3)
for _, row in df3.iterrows():
    tweet = str(row.get("Tweet Text", ""))
    app = row.get("App Name", "Nil")
    persona = detect_persona(tweet)
    all_reviews.append({
        "Platform": "Twitter",
        "Text": tweet,
        "App name": app,
        "Persona": persona
    })


all_reviews_df = pd.DataFrame(all_reviews)


output_reviews_path = os.path.join(output_folder, "scammer_persona_reviews.csv")
all_reviews_df.to_csv(output_reviews_path, index=False)


persona_summary_by_app = pd.pivot_table(
    all_reviews_df,
    index="App name",
    columns="Persona",
    aggfunc="size",
    fill_value=0
).reset_index()

persona_summary_by_app_path = os.path.join(output_folder, "persona_summary_by_app.csv")
persona_summary_by_app.to_csv(persona_summary_by_app_path, index=False)


persona_summary_by_platform = pd.pivot_table(
    all_reviews_df,
    index="Platform",
    columns="Persona",
    aggfunc="size",
    fill_value=0
).reset_index()

persona_summary_by_platform_path = os.path.join(output_folder, "persona_summary_by_platform.csv")
persona_summary_by_platform.to_csv(persona_summary_by_platform_path, index=False)

print("✅ Persona analysis completed.")
print(f"Reviews saved to: {output_reviews_path}")
print(f"App summary saved to: {persona_summary_by_app_path}")
print(f"Platform summary saved to: {persona_summary_by_platform_path}")
