import pandas as pd
import os
import re


timing_indicators = {
    "quick_escalation": [
        r"within days", r"suddenly asked", r"out of nowhere",
        r"started talking about money", r"pivot to investments",
        r"within a week", r"few days later", r"quickly changed"
    ],
    "delayed_escalation": [
        r"after weeks", r"months later", r"gained trust first",
        r"waited before asking", r"months", r"weeks"
    ]
}


instagram_file = "C:\\Users\\hp\\Desktop\\thu\\instagram_filtered_victim_reviews.csv"
reddit_file = "C:\\Users\\hp\\Desktop\\thu\\reddit_scam_reviews.csv"
twitter_file = "C:\\Users\\hp\\Desktop\\thu\\twitter_scam_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count"

os.makedirs(output_folder, exist_ok=True)


def classify_escalation(text):
    text = text.lower()
    found = []
    for label, patterns in timing_indicators.items():
        for pattern in patterns:
            if re.search(pattern, text):
                found.append(label)
                break
    return found if found else ['none']


df_insta = pd.read_csv(instagram_file)
df_insta['Platform'] = 'Instagram'
df_insta['Text'] = df_insta['Caption'].astype(str)
df_insta['Timing'] = df_insta['Text'].apply(classify_escalation)


df_reddit = pd.read_csv(reddit_file)
df_reddit['Platform'] = 'Reddit'
df_reddit['Text'] = df_reddit['Post Content'].astype(str)
df_reddit['Timing'] = df_reddit['Text'].apply(classify_escalation)


df_twitter = pd.read_csv(twitter_file)
df_twitter['Platform'] = 'Twitter'
df_twitter['Text'] = df_twitter['Tweet Text'].astype(str)
df_twitter['Timing'] = df_twitter['Text'].apply(classify_escalation)


all_data = pd.concat([df_insta, df_reddit, df_twitter], ignore_index=True)
all_data['App Name'] = all_data['App name'].fillna('Nil')


exploded = all_data.explode('Timing')


exploded.to_csv(os.path.join(output_folder, "timing_tagged_reviews.csv"), index=False)


summary_by_app = exploded.groupby(['App Name', 'Timing']).size().unstack(fill_value=0)
summary_by_app.to_csv(os.path.join(output_folder, "timing_summary_by_app.csv"))


summary_by_platform = exploded.groupby(['Platform', 'Timing']).size().unstack(fill_value=0)
summary_by_platform.to_csv(os.path.join(output_folder, "timing_summary_by_platform.csv"))

print("✅ Duration of interaction tagging complete.")
