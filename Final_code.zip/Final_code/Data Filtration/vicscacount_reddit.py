import os
import pandas as pd
import re
from collections import defaultdict


victim_keywords = [
    
    "romance scam",
    "pig butchering",
    "crypto scam",
    "investment scam",
    "crypto romance scam",
    "financial scam",
    "crypto fraud",
    "crypto scheme",
    "crypto trading scam",
    "lost my savings",
    "fake investment",
    "fake platform",

    
    "asked me to invest",
    "pushed me to invest",
    "asked me to download an app",
    "they introduced me to a mentor",
    "built trust and then",
    "pressured me to invest",
    "sent me a trading link",
    "i was added to a crypto group",
    "talked for weeks before asking for money",
    "he said he was a crypto trader",
    "she said she worked in crypto",
    "claimed to help me invest",
    "showed fake profits",
    "sent screenshots of returns",
    "i trusted them with my savings",
    "couldn’t withdraw",
    "wallet got drained",
    "they tricked me",
    "they promised high returns",
    "used a fake trading app",
    "sent money and then they disappeared",
    "they ghosted me after i sent money",
    "said we were soulmates and then asked for bitcoin",
    "said they lived abroad and needed help",
    "they wanted me to transfer crypto",
    "i lost thousands",
    "money vanished",
    "i got duped",
    "i was defrauded",
    "they convinced me to invest",
    "he made me believe it was real",
    "promised guaranteed profits",
    "told me i could double my money",
    "we met on a dating app and then...",
    "fake broker",
    "binance scam",
    "metamask scam",
    "they blocked me after i paid",
    "i thought it was love",
    "everything seemed perfect until money came up",
]
def classify_review(text):
    text = text.lower()
    for keyword in victim_keywords:
        if keyword in text:
            return "Victim"
    return "Not Scam Related"

def process_reviews(folder_path):
    results = defaultdict(lambda: {"Victims": 0, "Total Reviews": 0})
    all_reviews = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            app_name = file.split('.')[0]
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path)

            if "Content" not in df.columns:
                print(f"Skipping {file} due to missing 'Content' column.")
                continue

            for _, row in df.iterrows():
                review_text = str(row["Content"])
                category = classify_review(review_text)

                results[app_name]["Total Reviews"] += 1
                if category == "Victim":
                    results[app_name]["Victims"] += 1
                
                all_reviews.append([app_name, review_text, category])
    
    return results, all_reviews

def save_results(results, all_reviews, output_folder):
    os.makedirs(output_folder, exist_ok=True)  
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "Subreddit"}, inplace=True)

    if summary_df.empty or "Victims" not in summary_df.columns:
        print("No valid data found. Check input files or classification logic.")
        return

    
    total_victims = summary_df["Victims"].sum()
    total_reviews = summary_df["Total Reviews"].sum()

    summary_df = pd.concat([summary_df, pd.DataFrame([{
        "Subreddit": "Total",
        "Victims": total_victims,
        "Total Reviews": total_reviews
    }])], ignore_index=True)

    summary_df.to_csv(os.path.join(output_folder, "reddit_scam_summary.csv"), index=False)
    review_df = pd.DataFrame(all_reviews, columns=["Subreddit", "Post Content", "Category"])
    review_df.to_csv(os.path.join(output_folder, "reddit_classified_posts.csv"), index=False)

    print("✅ Processing complete. Results saved.")


folder_path = r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Reddit csv"
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\results"

results, all_reviews = process_reviews(folder_path)
save_results(results, all_reviews, output_folder)
