import csv
import os
import time
from instagrapi import Client
from instagrapi.exceptions import ClientError
from langdetect import detect, LangDetectException

def save_to_csv(data, filename='instagram_posts.csv'):
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['username', 'caption', 'media_path', 'post_url', 'likes', 'comments'])
        writer.writeheader()
        writer.writerows(data)

def download_media(cl, media, download_folder='downloads'):
    os.makedirs(download_folder, exist_ok=True)
    media_type = media.media_type
    media_path = None
    try:
        if media_type == 1:  
            media_path = cl.photo_download(media.pk, folder=download_folder)
        elif media_type == 2:  
            media_path = cl.video_download(media.pk, folder=download_folder)
        elif media_type == 8:  
            media_path = cl.album_download(media.pk, folder=download_folder)
    except Exception as e:
        print(f"Error downloading media for {media.pk}: {e}")
    return media_path

def is_english(text):
    try:
        return detect(text) == 'en'
    except LangDetectException:
        return False

def main():
    cl = Client()
    
    try:
        cl.login('', '')  # Replace with Instagram  #gmail, #password
        print("Login successful.")
    except ClientError as e:
        print(f"Login failed: {e}")
        return
    except Exception as e:
        print(f"Unexpected error during login: {e}")
        return

    hashtag_name = 'scams'  # Define the hashtag to search

    try:
        posts = cl.hashtag_medias_recent(hashtag_name, amount=100)  # Get 100 recent posts
    except Exception as e:
        print(f"Failed to fetch posts for #{hashtag_name}: {e}")
        return

    posts_data = []

    for post in posts:
        try:
            if is_english(post.caption_text):
                media_path = download_media(cl, post)
                post_data = {
                    'username': post.user.username,
                    'caption': post.caption_text,
                    'media_path': media_path,
                    'post_url': f"https://www.instagram.com/p/{post.code}/",
                    'likes': post.like_count,
                    'comments': post.comment_count
                }
                posts_data.append(post_data)
                print(f"Processed post by {post.user.username}")
                
                # Break if we have 100 posts
                if len(posts_data) >= 100:
                    break
                
                # Delay to avoid rate-limiting
                time.sleep(2)
        except Exception as e:
            print(f"Error processing post {post.id}: {e}")

    if posts_data:
        save_to_csv(posts_data)
        print("Data collection completed and saved to CSV.")
    else:
        print("No data collected.")

if __name__ == "__main__":
    main()