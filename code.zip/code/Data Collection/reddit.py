import praw
import csv
import requests
import os


reddit = praw.Reddit(
    client_id="",
    client_secret="",
    user_agent="",
    username="",
    password=""
)


subreddits = ["dating_advice"]
                #"ScamBaiting", 
                #"ScammerPayback",
                #"CryptoScams",
                #"Scams",
                #"legaladvice",
                #"relationships",
                #"Report_scams",
                #"CryptoRomanceScams"


keywords = [
                "Pig butchering",
                "Romance scam",
                "Online dating fraud",
                "Investment fraud",
                "Catfishing",
                "Fake love investment",
                "Crypto romance fraud",
                "Love scam",
                "Tinder scam",
                "Bumble scam",
                "Dating app scam"
           ]
            #"scam",
            #"Pig-baiting",
            #"Investment scam",
            #"Financial scam",
            #"Fraudulent investment",
            #"Scam experience",
            #"Scammer tactics",
            #"Scam victim",
            #"Fake investment",
            #"Crypto scam",
            #"Romance scam",
            #"Ponzi scheme",
            #"Phishing",
            #"Fake app",
            #"Malicious website",
            #"Telegram scam",
            #"WhatsApp scam",
            #"Signal scam",
            #"Text message scam",
           # "piggy bank fraud",
           # "oink crypto scheme",
           # "piggery scam",
           # "boar coin fraud",
           # "piglet investment scam",
           # "sty crypto swindle",
           # "hog pen scheme",
           # "sow crypto scam",
           # "piggy scam",
           # "boar market fraud",
           # "pig farm scheme",
           # "pigpen investment scam",
           # "oinker crypto fraud",
           # "porker scam",
           # "boar butcher scam",
           # "pigsty investment fraud",
           # "pig trough scam",
           # "piglet coin fraud",
           # "swineherd crypto scam",
           # "boar butchered investment" # change if you want to

# Create a directory for images
os.makedirs('images', exist_ok=True)


with open('reddit_posts.csv', mode='w', newline='', encoding='utf-8') as csv_file:
    fieldnames = ['Subreddit', 'Title', 'ID', 'Author', 'URL', 'Content', 'Image']
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    
    
    writer.writeheader()
    
    for subreddit_name in subreddits:
        subreddit = reddit.subreddit(subreddit_name)
        print(f"\nSearching in subreddit: {subreddit_name}")
        
       
        search_results = subreddit.search(keywords)
        
        for post in search_results:
            print("Title -", post.title)
            print("ID -", post.id)
            print("Author -", post.author)
            print("URL -", post.url)
            print("Content -", post.selftext[:300])  # Print the first 100 characters of the content for preview
            print("-" * 30)
            
            
            image_filename = ''
            
            
            if post.url.endswith(('jpg', 'jpeg', 'png', 'gif')):
                try:
                  
                    response = requests.get(post.url)
                    if response.status_code == 200:
                        
                        image_filename = os.path.join('images', f"{post.id}.{post.url.split('.')[-1]}")
                        with open(image_filename, 'wb') as img_file:
                            img_file.write(response.content)
                except Exception as e:
                    print(f"Failed to download image: {e}")
            
          
            writer.writerow({
                'Subreddit': subreddit_name,
                'Title': post.title,
                'ID': post.id,
                'Author': str(post.author),
                'URL': post.url,
                'Content': post.selftext,
                'Image': image_filename
            })
