import praw
import csv
import requests
import os
import time
import html


reddit = praw.Reddit(
    client_id="",
    client_secret="",
    user_agent="",
    username="",
    password=""
)

subreddits = ["usanews"] 



keywords = [
    "Tinder scam", 
    "Bumble scam",
    "OkCupid scam",
    "dating app fraud",
    "Hinge scam",
    "Match scam",
    "pig butchering",
    #"catfishing",
    #"crypto scam",
    "crypto romance scam"
    "romance scam",
    "Dating app scam"
]

os.makedirs('images', exist_ok=True)


with open('reddit_posts.csv', mode='w', newline='', encoding='utf-8') as csv_file:
    fieldnames = ['Subreddit', 'Title', 'ID', 'Author', 'URL', 'Content', 'Image']
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    
    
    writer.writeheader()
    
   
    for subreddit_name in subreddits:
        subreddit = reddit.subreddit(subreddit_name)
        print(f"\nSearching in subreddit: {subreddit_name}")
        
        
        for keyword in keywords:
            print(f"Searching for keyword: {keyword}")
            search_results = subreddit.search(keyword, limit=100)  # Increase limit as needed
            
            for post in search_results:
                print("Title -", post.title)
                print("ID -", post.id)
                print("Author -", post.author)
                print("URL -", post.url)
                print("Content -", post.selftext[:300])  # Preview first 300 characters of content
                print("-" * 30)
                
                
                image_filename = ''
                
                
                if post.url.endswith(('jpg', 'jpeg', 'png', 'gif')):
                    try:
                        
                        response = requests.get(post.url)
                        if response.status_code == 200:
                            
                            image_filename = os.path.join('images', f"{post.id}.{post.url.split('.')[-1]}")
                            with open(image_filename, 'wb') as img_file:
                                img_file.write(response.content)
                    except Exception as e:
                        print(f"Failed to download image: {e}")
                
                
                post_content = post.selftext if post.selftext else "No content available"
                
                
                post_content = post_content.replace('\n', ' ').replace('\r', ' ')
                post_content = html.unescape(post_content)  
                
               
                writer.writerow({
                    'Subreddit': subreddit_name,
                    'Title': post.title,
                    'ID': post.id,
                    'Author': str(post.author),
                    'URL': post.url,
                    'Content': post_content,
                    'Image': image_filename
                })
                
                
                time.sleep(2)

print("Data collection completed.")
