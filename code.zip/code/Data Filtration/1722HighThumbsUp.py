import os
import pandas as pd
from collections import Counter

# Paths
input_folder = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
input_file = "DatingAppReviewsDataset2017-22.csv"
file_path = os.path.join(input_folder, input_file)

output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\ThumbsUp_based_analysis"
os.makedirs(output_folder, exist_ok=True)


scam_keywords = [
    "scam", "fake", "fraud", "money", "bitcoin", "crypto", "investment",
    "catfish", "suspicious", "cheat", "phishing", "stolen", "impersonate",
    "romance", "blackmail", "trap", "deceive", "trick", "blocked"
]


try:
    df = pd.read_csv(file_path)
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()


df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]


if "#thumbsup" in df.columns:
    df.rename(columns={"#thumbsup": "thumbsup"}, inplace=True)
if "rating" in df.columns:
    df.rename(columns={"rating": "score"}, inplace=True)


if "thumbsup" not in df.columns or "content" not in df.columns:
    print("❌ Required columns ('thumbsup' or 'content') not found.")
    exit()


df["thumbsup"] = pd.to_numeric(df["thumbsup"], errors="coerce")


top_reviews = df[df["thumbsup"] >= 5].copy()

if top_reviews.empty:
    print("⚠️ No high-engagement reviews found.")
else:
    
    def find_keywords(text):
        text = str(text).lower()
        return [word for word in scam_keywords if word in text]

    top_reviews["scam_keywords"] = top_reviews["content"].apply(find_keywords)
    all_keywords = [kw for sublist in top_reviews["scam_keywords"] for kw in sublist]

    
    keyword_counts = Counter(all_keywords)
    keyword_df = pd.DataFrame(keyword_counts.items(), columns=["Keyword", "Frequency"])
    keyword_df.sort_values(by="Frequency", ascending=False, inplace=True)

    
    top_reviews.to_csv(os.path.join(output_folder, "top_liked_issues.csv"), index=False)
    keyword_df.to_csv(os.path.join(output_folder, "scam_keyword_frequency.csv"), index=False)
    top_reviews.to_csv(os.path.join(output_folder, "top_liked_with_keywords.csv"), index=False)

    print("✅ Analysis complete. Files saved in:")
    print("→ top_liked_issues.csv")
    print("→ scam_keyword_frequency.csv")
    print("→ top_liked_with_keywords.csv")
