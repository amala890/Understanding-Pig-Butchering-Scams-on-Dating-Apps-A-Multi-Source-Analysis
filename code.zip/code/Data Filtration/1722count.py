import os
import pandas as pd
from collections import defaultdict


victim_keywords = [ "lost money", "tricked", "investment scam", "crypto scam", "stole my money", "got scammed",
    "cheated", "deceived", "fraud", "was taken advantage of", "scammed out of", "scam artist",
    "false promises", "never received", "no return", "financial loss", "wasted money",
    "tricked into investing", "fake investment", "promised high returns", "stolen funds", 
    "lost savings", "convinced me to invest", "pretended to love me", "romance scam","blockchain", "wallet address", "send money", "bank transfer", 
    "crypto trading scam", "fake trading app", "withdrawal blocked", "unable to withdraw", 
    "future together",
    "external app", "WhatsApp", "Telegram", "Skype",
    "Line", "WeChat", "move to another app", "private chat", "secretive", "no video call",
    "no phone call", "no meetup", "avoid in-person", "long distance", "military",
    "engineer", "doctor", "oil rig", "working overseas", "urgent", "emergency",
    "true love", "heartbroken", "broken trust", "lied to", "deceived", "betrayed",
    "invested and lost", "high returns scam", "fraudulent trading", "scammed by lover", "get rich quick", "high returns", "low risk", "financial freedom", 
    "crypto romance scam", "deceived into investing", "promised profits", "fake broker", 
    "fake financial advisor", "investment fraud", "crypto manipulation", "profits", "returns", "money disappeared"]
scammer_keywords = ["full of scammers", "fake profiles", "too many scammers", "lots of scam accounts", 
    "fraudulent profiles", "scam accounts", "scam artists", "scam messages", "fraudulent activity",
    "fake dating profiles", "romance scammers", "sweet talk scam", "fake love", "love bombing", 
    "fake relationships", "fake romance", "suspicious investment offers", "cryptocurrency scam", 
    "investment fraud", "trading platform scam", "bitcoin scam", "fake trading signals", 
    "crypto scammer", "investment opportunity scam", "love scammer", "fake financial expert", 
    "trading scam", "fake mentorship", "romance fraud", "emotional manipulation for money", 
    "dating app full of scammers", "fake crypto guru", "fake investment platform", "stolen information",
    "untrustworthy", "unreliable", "no customer service", "no response", "ignored reports",
    "ignored complaints",
    "too good to be true returns", "scammers everywhere", "no moderation", "no support", "reported but no action",
    "fake accounts", "fraudulent behavior"]

def classify_review(text):
    text = text.lower()
    
    for keyword in victim_keywords:
        if keyword in text:
            return "Victim"
    
    for keyword in scammer_keywords:
        if keyword in text:
            return "Scammer Mention"
    
    return "Not Scam Related"

def process_public_dataset(folder_path):
    results = defaultdict(lambda: {"Victims": 0, "Scammer Mentions": 0, "Total Reviews": 0})
    all_reviews = []
    
    for file in os.listdir(folder_path):
        if file.endswith(".csv"):  
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, dtype=str, low_memory=False)
            
            
            if "content" not in df.columns or "userName" not in df.columns or "App" not in df.columns:
                print(f"Skipping {file} due to missing columns.")
                continue
            
            for _, row in df.iterrows():
                review_text = str(row["content"])  
                app_name = row["App"]  
                
                category = classify_review(review_text)
                
                results[app_name]["Total Reviews"] += 1
                if category == "Victim":
                    results[app_name]["Victims"] += 1
                elif category == "Scammer Mention":
                    results[app_name]["Scammer Mentions"] += 1
                
                all_reviews.append([app_name, row["userName"], review_text, category])
    
    return results, all_reviews

def save_public_results(results, all_reviews, output_folder):
    
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)

    
    total_row = {
        "App Name": "TOTAL",
        "Victims": summary_df["Victims"].sum(),
        "Scammer Mentions": summary_df["Scammer Mentions"].sum(),
        "Total Reviews": summary_df["Total Reviews"].sum(),
    }
    summary_df = pd.concat([summary_df, pd.DataFrame([total_row])], ignore_index=True)
    
    summary_df.to_csv(os.path.join(output_folder, "public_dataset_summary.csv"), index=False)
    
    
    review_df = pd.DataFrame(all_reviews, columns=["App Name", "User Name", "Review Content", "Category"])
    scam_reviews_df = review_df[review_df["Category"] != "Not Scam Related"]
    scam_reviews_df.to_csv(os.path.join(output_folder, "public_classified_reviews.csv"), index=False)
    
    print("Processing complete. Public dataset results saved.")


public_dataset_folder = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"  
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count" 

results, all_reviews = process_public_dataset(public_dataset_folder)
save_public_results(results, all_reviews, output_folder)
