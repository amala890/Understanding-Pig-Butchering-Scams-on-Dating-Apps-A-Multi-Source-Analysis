import os
import pandas as pd
import re
from collections import defaultdict


scam_indicators = {
    "financial_loss": [
        r"lost \$\d+", r"invested \$\d+", "never got my money back",
        "stole my money", "scammed me out of", "financial ruin"
    ],
    "emotional_harm": [
        "betrayed", "heartbroken", "manipulative", "took advantage of my trust",
        "felt used", "emotional damage", "destroyed my confidence", "felt betrayed",
        "very manipulative", "emotionally drained", "trust was broken", "played with my feelings",
        "feels like I was tricked", "manipulative behavior", "left me feeling empty",
        "emotional abuse", "feeling deceived", "broken trust", "mentally exhausted",
        "led on", "hurt me emotionally", "emotional manipulation", "used for money",
        "made me feel worthless", "toying with my emotions", "used my feelings against me"
    ],
    "amounts": [
        r"\$\d{1,3}(?:,\d{3})*",     # $1,000 or $100000
        r"\d+\s?(USD|dollars)"       # 1000 USD or 500 dollars
    ]
}


def extract_amounts(text):
    amounts = re.findall(r"\$?\d{1,3}(?:,\d{3})*|\d+\s?(USD|dollars)", text)
    values = []
    for amt in amounts:
        amt_clean = re.sub(r"[^\d]", "", amt if isinstance(amt, str) else "")
        if amt_clean.isdigit():
            values.append(int(amt_clean))
    return values


def classify_review(text):
    category_counts = defaultdict(int)
    found_amounts = []

    for category, patterns in scam_indicators.items():
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                category_counts[category] += 1
                if category == "amounts":
                    found_amounts.extend(extract_amounts(text))
    return category_counts, found_amounts

def process_file(file_path):
    df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
    if "content" not in df.columns or "App" not in df.columns:
        print("Missing required columns.")
        return None

    summary_results = defaultdict(lambda: {"financial_loss": 0, "emotional_harm": 0, "amounts": 0, "max_reported_amount": 0})
    classified_reviews = []

    for _, row in df.iterrows():
        text = str(row["content"])
        app_name = str(row["App"]).strip()

        category_counts, found_amounts = classify_review(text)

        if any(category_counts.values()):
            classified_reviews.append({
                "app_name": app_name,
                "review_text": text,
                "financial_loss": category_counts["financial_loss"],
                "emotional_harm": category_counts["emotional_harm"],
                "amounts_mentioned": category_counts["amounts"],
                "max_amount_in_review": max(found_amounts) if found_amounts else 0
            })

        for category in ["financial_loss", "emotional_harm", "amounts"]:
            summary_results[app_name][category] += category_counts.get(category, 0)

        if found_amounts:
            max_amt = max(found_amounts)
            if max_amt > summary_results[app_name]["max_reported_amount"]:
                summary_results[app_name]["max_reported_amount"] = max_amt

    summary_df = pd.DataFrame([
        {
            "app_name": app,
            "financial_loss": data["financial_loss"],
            "emotional_harm": data["emotional_harm"],
            "amounts": data["amounts"],
            "max_reported_amount": data["max_reported_amount"]
        }
        for app, data in summary_results.items()
    ])

    classified_df = pd.DataFrame(classified_reviews)

    return summary_df, classified_df


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
file_name = "DatingAppReviewsDataset2017-22.csv"
file_path = os.path.join(folder_path, file_name)

output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\emofinimpacts_reviews"
os.makedirs(output_folder, exist_ok=True)


summary_df, classified_df = process_file(file_path)


summary_df.to_csv(os.path.join(output_folder, "DatingAppReviewsDataset2017-22_summary.csv"), index=False)
classified_df.to_csv(os.path.join(output_folder, "DatingAppReviewsDataset2017-22_classified_reviews.csv"), index=False)

print("✅ Finished. Summary and detailed classified reviews saved.")
