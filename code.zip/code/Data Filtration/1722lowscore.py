import pandas as pd
import os

def generate_Rating_summary(file_path):
    try:
        df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
    except Exception as e:
        print(f"Error reading file: {e}")
        return None, None

    
    df["Rating"] = pd.to_numeric(df["Rating"], errors="coerce")
    df["App"] = df["App"].fillna("Unknown").str.strip()

    
    valid_Ratings = df[df["Rating"].isin([1, 2]) | (df["Rating"] > 3)]

    
    summary = valid_Ratings.groupby("App").agg(
        Rating_1_count=pd.NamedAgg(column="Rating", aggfunc=lambda x: (x == 1).sum()),
        Rating_2_count=pd.NamedAgg(column="Rating", aggfunc=lambda x: (x == 2).sum()),
        Rating_more_than_3_count=pd.NamedAgg(column="Rating", aggfunc=lambda x: (x > 3).sum())
    ).reset_index()

    
    low_Rating_reviews = df[df["Rating"].isin([1, 2])].copy()

    return summary, low_Rating_reviews


input_folder = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\DatingReviewsDataset2017-22"
input_file = "DatingAppReviewsDataset2017-22.csv"
file_path = os.path.join(input_folder, input_file)

output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\Rating_based_analysis"
os.makedirs(output_folder, exist_ok=True)


summary_df, low_Rating_df = generate_Rating_summary(file_path)

if summary_df is not None:
    summary_output = os.path.join(output_folder, "review_Rating_summary_by_app.csv")
    low_Rating_output = os.path.join(output_folder, "low_Rating_reviews.csv")

    summary_df.to_csv(summary_output, index=False)
    low_Rating_df.to_csv(low_Rating_output, index=False)

    print("✅ Summary saved to:", summary_output)
    print("✅ Low-Rating reviews saved to:", low_Rating_output)
else:
    print("❌ Failed to process the file.")
