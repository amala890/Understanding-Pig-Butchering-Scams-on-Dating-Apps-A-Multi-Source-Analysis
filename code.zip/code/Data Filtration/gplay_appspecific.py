import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = input_folder


input_file = os.path.join(input_folder, "scam_reviews_combined.csv")
all_scam_reviews_df = pd.read_csv(input_file)


app_specific_keywords = {
    "poor_detection": [
        "didn't remove scammer", "ignored my report", "no action taken",
        "still seeing fake profiles", "scammers everywhere", "no moderation",
        "reported but still active", "no verification", "fake accounts"
    ],
    "safety_suggestions": [
        "needs verification", "should screen profiles", "better moderation",
        "require ID check", "photo verification", "background checks",
        "ban suspicious accounts", "improve reporting", "protect users"
    ]
}


def flag_app_issues(text):
    issues = {}
    if isinstance(text, str):
        text_lower = text.lower()
        issues["poor_detection"] = any(keyword in text_lower for keyword in app_specific_keywords["poor_detection"])
        issues["safety_suggestions"] = any(keyword in text_lower for keyword in app_specific_keywords["safety_suggestions"])
    return issues


all_scam_reviews_df["app_issues"] = all_scam_reviews_df["content"].apply(flag_app_issues)
issues_expanded = all_scam_reviews_df["app_issues"].apply(pd.Series)
all_scam_reviews_df = pd.concat([all_scam_reviews_df.drop("app_issues", axis=1), issues_expanded], axis=1)


app_trends = all_scam_reviews_df.groupby("app_name").agg({
    "poor_detection": "sum",
    "safety_suggestions": "sum",
    "is_scam": "count"
}).rename(columns={"is_scam": "total_scam_reviews"})


app_trends["poor_detection_pct"] = (app_trends["poor_detection"] / app_trends["total_scam_reviews"]) * 100
app_trends["safety_suggestions_pct"] = (app_trends["safety_suggestions"] / app_trends["total_scam_reviews"]) * 100


app_trends_csv = os.path.join(output_folder, "app_specific_scam_trends.csv")
app_trends.to_csv(app_trends_csv)


plt.figure(figsize=(30, 10))
app_trends[["poor_detection_pct", "safety_suggestions_pct"]].plot(kind="bar", stacked=False)
plt.title("App-Specific Scam Detection Issues & User Suggestions")
plt.ylabel("Percentage of Scam Reviews")
plt.xlabel("Dating App")
plt.xticks(rotation=90)
plt.legend(title="Metric", labels=["Poor Detection Complaints", "Safety Suggestions"])
plt.tight_layout()
plt.show()


sns.lmplot(
    data=app_trends.reset_index(),
    x="poor_detection_pct",
    y="safety_suggestions_pct",
    hue="app_name",
    height=6,
    aspect=1.5
)
plt.title("Do More Complaints Lead to More Suggestions?")
plt.xlabel("Poor Detection Complaints (%)")
plt.ylabel("Safety Suggestions (%)")
plt.show()


safety_reviews_df = all_scam_reviews_df[all_scam_reviews_df["safety_suggestions"] == True]
columns_to_save = ["app_name", "content", "safety_suggestions"]
suggestion_csv = os.path.join(output_folder, "six_safety_suggestion_reviews.csv")
safety_reviews_df[columns_to_save].to_csv(suggestion_csv, index=False)


print("Sample User Suggestions for Improved Safety:\n")
for i, suggestion in enumerate(safety_reviews_df["content"].head(10), 1):
    print(f"{i}. {suggestion}\n")
