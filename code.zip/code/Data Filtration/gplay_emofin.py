import os
import re
import pandas as pd
import matplotlib.pyplot as plt


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'


input_file = os.path.join(input_folder, 'scam_reviews_combined.csv')
all_scam_reviews_df = pd.read_csv(input_file)


impact_keywords = {
    "financial_loss": [
        r"lost \$\d+", r"invested \$\d+", "never got my money back",
        "stole my money", "scammed me out of", "financial ruin"
    ],
    "emotional_harm": [
        "betrayed", "heartbroken", "manipulative", "took advantage of my trust",
        "felt used", "emotional damage", "destroyed my confidence"
    ],
    "amounts": [
        r"\$\d{1,3}(?:,\d{3})*",
        r"\d+\s?(USD|dollars)"
    ]
}

def detect_impacts(text):
    impacts = {}
    if isinstance(text, str):
        
        impacts["financial_loss"] = any(
            re.search(pattern, text, re.IGNORECASE)
            for pattern in impact_keywords["financial_loss"]
        )
        
        impacts["emotional_harm"] = any(
            keyword in text.lower()
            for keyword in impact_keywords["emotional_harm"]
        )
        
        amounts = []
        for pattern in impact_keywords["amounts"]:
            amounts.extend(re.findall(pattern, text, re.IGNORECASE))
        impacts["amounts"] = amounts if amounts else None
    return impacts


all_scam_reviews_df["impacts"] = all_scam_reviews_df["content"].apply(detect_impacts)
all_scam_reviews_df = pd.concat([
    all_scam_reviews_df.drop(columns=["impacts"]),
    all_scam_reviews_df["impacts"].apply(pd.Series)
], axis=1)


impact_stats = all_scam_reviews_df.groupby("app_name").agg({
    "financial_loss": "sum",
    "emotional_harm": "sum",
    "is_scam": "count"
}).rename(columns={"is_scam": "total_scam_reviews"})

impact_stats["financial_loss_pct"] = (impact_stats["financial_loss"] / impact_stats["total_scam_reviews"]) * 100
impact_stats["emotional_harm_pct"] = (impact_stats["emotional_harm"] / impact_stats["total_scam_reviews"]) * 100


impact_stats.to_csv(os.path.join(output_folder, "emotional_financial_impact_by_app.csv"))


plt.figure(figsize=(12, 6))
impact_stats[["financial_loss_pct", "emotional_harm_pct"]].plot(kind="bar", stacked=True, figsize=(12, 6))
plt.title("Financial vs. Emotional Harm Prevalence by App")
plt.ylabel("Percentage of Scam Reviews")
plt.xticks(rotation=45)
plt.tight_layout()
plt.legend(title="Impact Type")
plt.savefig(os.path.join(output_folder, "emotional_financial_impact.png"))
plt.show()


amounts = (
    all_scam_reviews_df["amounts"]
    .dropna()
    .explode()
    .str.extract(r'(\d+[,\.]?\d*)')[0]
    .str.replace(',', '', regex=False)
    .dropna()
    .astype(float)
)


if not amounts.empty:
    plt.figure(figsize=(10, 6))
    plt.hist(amounts, bins=20, color="red", edgecolor="black")
    plt.title("Distribution of Reported Financial Losses")
    plt.xlabel("Amount Lost (USD)")
    plt.ylabel("Frequency")
    mean_loss = amounts.mean()
    median_loss = amounts.median()
    plt.axvline(mean_loss, color="k", linestyle="dashed", linewidth=1,
                label=f"Mean: ${mean_loss:,.2f}\nMedian: ${median_loss:,.2f}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, "financial_loss_histogram.png"))
    plt.show()

    
    print(f"Financial Loss Statistics:\n"
          f"- Mean: ${mean_loss:,.2f}\n"
          f"- Median: ${median_loss:,.2f}\n"
          f"- Max: ${amounts.max():,.2f}\n"
          f"- Total Reported Loss: ${amounts.sum():,.2f}")
else:
    print("No monetary amounts found in reviews.")
