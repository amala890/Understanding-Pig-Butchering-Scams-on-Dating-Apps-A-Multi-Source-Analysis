import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


input_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'
output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result'


os.makedirs(output_folder, exist_ok=True)

input_file = os.path.join(input_folder, "scam_reviews_combined.csv")  # change filename if needed
all_scam_reviews_df = pd.read_csv(input_file)


timing_keywords = {
    "quick_escalation": [
        "within days", "suddenly asked", "out of nowhere",
        "started talking about money", "pivot to investments",
        "within a week", "few days later", "quickly changed"
    ],
    "delayed_escalation": [
        "after weeks", "months later", "gained trust first",
        "waited before asking"
    ]
}


def detect_timing(text):
    if not isinstance(text, str):
        return "no_mention"
    text_lower = text.lower()
    for timing_type, keywords in timing_keywords.items():
        if any(keyword in text_lower for keyword in keywords):
            return timing_type
    return "no_mention"


all_scam_reviews_df["timing_pattern"] = all_scam_reviews_df["content"].apply(detect_timing)


timing_stats = all_scam_reviews_df.groupby(["app_name", "timing_pattern"]).size().unstack(fill_value=0)


timing_stats["escalation_ratio"] = timing_stats["quick_escalation"] / timing_stats.get("delayed_escalation", 1).replace(0, 1)


timing_stats_file = os.path.join(output_folder, "timing_patterns_by_app.csv")
timing_stats.to_csv(timing_stats_file)


plt.figure(figsize=(20, 9))
sns.barplot(
    data=timing_stats.reset_index(),
    x="app_name",
    y="quick_escalation",
    color="red",
    label="Quick Escalation (Days)"
)
sns.barplot(
    data=timing_stats.reset_index(),
    x="app_name",
    y="delayed_escalation",
    color="orange",
    label="Delayed Escalation (Weeks+)"
)
plt.title("Speed of Financial Escalation by App")
plt.ylabel("Number of Reviews")
plt.xticks(rotation=90)
plt.legend()
plt.tight_layout()
plt.show()


timing_reviews = all_scam_reviews_df[all_scam_reviews_df["timing_pattern"].isin(["quick_escalation", "delayed_escalation"])]

timing_reviews_file = os.path.join(output_folder, "timing_pattern_reviews.csv")
timing_reviews.to_csv(timing_reviews_file, index=False)

timing_reviews_text_only_file = os.path.join(output_folder, "timing_pattern_reviews_text_only.csv")
timing_reviews[["content", "timing_pattern"]].to_csv(timing_reviews_text_only_file, index=False)
