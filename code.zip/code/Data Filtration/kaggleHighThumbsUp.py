import os
import pandas as pd

folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\HighThumbsUp_Reviews"
os.makedirs(output_folder, exist_ok=True)

high_engagement_reviews = []

for file in os.listdir(folder_path):
    if file.endswith(".csv"):
        file_path = os.path.join(folder_path, file)
        try:
            df = pd.read_csv(file_path, encoding="ISO-8859-1")
            if "content" in df.columns and "thumbsUpCount" in df.columns:
                df["thumbsUpCount"] = pd.to_numeric(df["thumbsUpCount"], errors="coerce").fillna(0)
                df["score"] = pd.to_numeric(df["score"], errors="coerce").fillna(0)
                app_name = os.path.splitext(file)[0]
                df["App"] = app_name

                high_df = df[df["thumbsUpCount"] >= 5]
                if not high_df.empty:
                    high_engagement_reviews.append(high_df)
                else:
                    print(f"No high-engagement reviews found in {file}")
            else:
                print(f"Skipping {file}: Missing 'content' or 'thumbsUpCount' column.")
        except Exception as e:
            print(f"Error reading {file}: {e}")


if high_engagement_reviews:
    combined_df = pd.concat(high_engagement_reviews, ignore_index=True)
    combined_df.to_csv(os.path.join(output_folder, "high_engagement_reviews.csv"), index=False)

    
    summary = combined_df.groupby("App").size().reset_index(name="HighThumbsUpReviewCount")
    summary.to_csv(os.path.join(output_folder, "high_engagement_summary.csv"), index=False)

    
    top_liked = combined_df[["App", "content", "thumbsUpCount"]].sort_values(by="thumbsUpCount", ascending=False)
    top_liked.to_csv(os.path.join(output_folder, "top_liked_issues.csv"), index=False)

    print("✅ High-engagement reviews saved.")
else:
    print("⚠️ No high-engagement reviews found in any file.")
