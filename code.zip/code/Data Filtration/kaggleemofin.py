import os
import pandas as pd
import re
from collections import defaultdict


scam_indicators = {
    "financial_loss": [
        r"lost \$\d+", r"invested \$\d+", "never got my money back",
        "stole my money", "scammed me out of", "financial ruin"
    ],
    "emotional_harm": [
        "betrayed", "heartbroken", "manipulative", "took advantage of my trust",
        "felt used", "emotional damage", "destroyed my confidence", "felt betrayed",
        "very manipulative", "emotionally drained", "trust was broken", "played with my feelings",
        "feels like I was tricked", "manipulative behavior", "left me feeling empty",
        "emotional abuse", "feeling deceived", "broken trust", "mentally exhausted",
        "led on", "hurt me emotionally", "emotional manipulation", "used for money",
        "made me feel worthless", "toying with my emotions", "used my feelings against me"
    ],
    "amounts": [
        r"\$\d{1,3}(?:,\d{3})*",  
        r"\d+\s?(usd|dollars)"     
    ]
}


pricing_keywords = [
    "premium", "subscription", "membership", "paywall", "pay to see", "paid feature", 
    "must pay", "have to pay", "upgrade to", "monthly fee", "spending $", "subscription fee",
    "can't see", "need to pay", "costs $", "price of", "overpriced", "paying $", "per month"
]

def extract_amounts(text):
    text = text.lower()
    if any(kw in text for kw in pricing_keywords):
        return []
    patterns = [
        r"\$\s?[\d,]+(?:\.\d+)?",
        r"[\d,]+(?:\.\d+)?\s?(usd|dollars)"
    ]
    matches = []
    for pattern in patterns:
        found = re.findall(pattern, text)
        matches.extend(found)
    cleaned_amounts = []
    for amt in matches:
        if isinstance(amt, tuple): amt = amt[0]
        amt = re.sub(r'[^\d.]', '', amt)
        try:
            cleaned_amounts.append(float(amt))
        except:
            continue
    return cleaned_amounts

def classify_review(text):
    text = text.lower()
    category_counts = defaultdict(int)
    for category, keywords in scam_indicators.items():
        for keyword in keywords:
            if re.search(r"\b" + re.escape(keyword) + r"\b", text):
                category_counts[category] += 1
    return category_counts

def process_reviews(folder_path):
    results = defaultdict(lambda: {category: 0 for category in scam_indicators})
    all_reviews = []
    max_amounts = defaultdict(list)

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            app_name = file.split('.')[0]
            file_path = os.path.join(folder_path, file)
            try:
                df = pd.read_csv(file_path, encoding="ISO-8859-1", dtype=str, low_memory=False)
            except Exception as e:
                print(f"Error reading {file}: {e}")
                continue

            if df.empty or "content" not in df.columns:
                continue

            for _, row in df.iterrows():
                review_text = str(row["content"]).lower()
                category_counts = classify_review(review_text)

                for category, count in category_counts.items():
                    results[app_name][category] += count

                if any(category_counts.values()):
                    all_reviews.append([app_name, review_text, dict(category_counts)])

               
                extracted = extract_amounts(review_text)
                if extracted:
                    max_amounts[app_name].extend(extracted)

    return results, all_reviews, max_amounts

def save_results(results, all_reviews, max_amounts, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)

   
    summary_df["max_amount"] = summary_df["App Name"].apply(
        lambda x: max(max_amounts[x]) if max_amounts[x] else 0
    )
    summary_df["min_amount"] = summary_df["App Name"].apply(
        lambda x: min(max_amounts[x]) if max_amounts[x] else 0
    )

    summary_df.to_csv(os.path.join(output_folder, "scam_indicators_summary.csv"), index=False)

    review_df = pd.DataFrame(all_reviews, columns=["App Name", "Review Content", "Scam Categories"])
    review_df.to_csv(os.path.join(output_folder, "classified_scam_reviews.csv"), index=False)

    print("Processing complete. Results saved.")


folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\emofinimpacts_reviews"

results, all_reviews, max_amounts = process_reviews(folder_path)
save_results(results, all_reviews, max_amounts, output_folder)
