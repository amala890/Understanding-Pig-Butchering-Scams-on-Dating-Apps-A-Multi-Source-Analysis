import os
import pandas as pd
from collections import defaultdict


scam_context_words = [
    "investment", "bitcoin", "crypto", "money", "profit", "trading", "scammer",
    "link", "wallet", "send", "transfer", "address", "platform", "exchange"
]


scam_indicators = {
    "crypto_wallets": ["crypto wallet", "blockchain address", "btc address", "eth wallet"],
    "investment_sites": ["investment portal", "trading platform", "forex site", "binance", "coinbase", "fake exchange"],
    "payment_apps": ["paypal", "venmo", "cashapp", "zelle", "western union"],
    "whatsapp": ["whatsapp", "whats app"],
    "telegram": ["telegram", "tele gram"],
    "skype": ["skype"],
    "snapchat": ["snapchat", "snap chat"],
    "signal": ["signal"],
    "suspicious_links": ["suspicious link", "phishing site", "fake website", "http://", "https://"]
}

def classify_review(text):
    text = text.lower()
    category_counts = defaultdict(int)

    for category, keywords in scam_indicators.items():
        for keyword in keywords:
            if keyword.lower() in text:
                category_counts[category] += 1
    
    return category_counts

def process_reviews(folder_path):
    results = defaultdict(lambda: {category: 0 for category in scam_indicators})
    all_reviews = []
    
    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            app_name = os.path.splitext(file)[0]
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path, encoding="ISO-8859-1")
            
            if "content" not in df.columns:
                print(f"Skipping {file} due to missing 'content' column.")
                continue

            
            for _, row in df.iterrows():
                review_text = str(row["content"]).lower().strip()
                category_counts = classify_review(review_text)

                if category_counts and sum(category_counts.values()) > 0:
                    
                    if any(word in review_text for word in scam_context_words):
                        if sum(category_counts.values()) >= 2:
                            for category, count in category_counts.items():
                                results[app_name][category] += count
                            all_reviews.append([app_name, review_text, dict(category_counts)])
    
    return results, all_reviews

def save_results(results, all_reviews, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    summary_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
    summary_df.rename(columns={"index": "App Name"}, inplace=True)
    summary_df.to_csv(os.path.join(output_folder, "scam_indicators_summary.csv"), index=False)
    
    review_df = pd.DataFrame(all_reviews, columns=["App Name", "Review Content", "Scam Categories"])
    review_df.to_csv(os.path.join(output_folder, "classified_scam_reviews.csv"), index=False)

    print("Processing complete. Results saved.")

# Example usage
folder_path = "C:\\Users\\hp\\Desktop\\Full_code_Amala_Romance\\Kaggle"
output_folder = "C:\\Users\\hp\\Desktop\\Project\\Full_code_Amala (1)\\Full_code_Amala\\platform_reviews"

results, all_reviews = process_reviews(folder_path)
save_results(results, all_reviews, output_folder)
