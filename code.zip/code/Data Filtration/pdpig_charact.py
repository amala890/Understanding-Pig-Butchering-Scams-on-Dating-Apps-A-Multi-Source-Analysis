import pandas as pd
import os
import re
from collections import defaultdict


characteristics_patterns = {
    "Generic Profile Picture": [
        r"too good looking", r"very attractive", r"model looking", r"stock photo", r"fake profile picture", r"military"
    ],
    "Claims of Living Abroad": [
        r"lives abroad", r"working overseas", r"from another country", r"moved to [a-z]+", 
        r"he said he's in [a-z]+", r"she's in dubai", r"currently in [a-z]+", r"Hong Kong", r"dubai", r"Dubai"
    ],
    "Inconsistent Profile Information": [
        r"profile didn’t match", r"inconsistent details", r"info didn’t add up", 
        r"profile said one thing", r"different name"
    ],
    "Pushing Investment Opportunities": [
        r"asked me to invest", r"told me about crypto", r"investment opportunity", 
        r"financial freedom", r"join his trading", r"crypto scheme", r"forced to invest",
        r"persistent about investing", r"bitcoin investment", r"she kept promoting"
    ],
    "Shifting to Off-Platform Channels": [
        r"move to whatsapp", r"talk on telegram", r"switch to line", 
        r"add me on signal", r"we left the app", r"asked for my number" r"whats app", r"whatsapp", r"telegram",
    ],
    "Avoiding Video/In-Person Meetings": [
        r"refused video call", r"never met", r"avoided face to face", 
        r"excuses for not meeting", r"didn’t want to video chat", 
        r"always busy to meet", r"said camera is broken"
    ]
}


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


try:
    df1 = pd.read_csv(victim_reviews_file1, encoding="utf-8-sig")
    df2 = pd.read_csv(victim_reviews_file2, encoding="utf-8-sig")
except UnicodeDecodeError:
    df1 = pd.read_csv(victim_reviews_file1, encoding="ISO-8859-1")
    df2 = pd.read_csv(victim_reviews_file2, encoding="ISO-8859-1")


combined_df = pd.concat([df1, df2], ignore_index=True)


matched_reviews = []
summary_by_app = defaultdict(lambda: defaultdict(int))


for _, row in combined_df.iterrows():
    app_name = row["App Name"]
    user = row["User Name"]
    content = str(row["Review Content"]).lower()

    matched_categories = []
    for category, patterns in characteristics_patterns.items():
        for pattern in patterns:
            if re.search(pattern, content):
                matched_categories.append(category)
                summary_by_app[app_name][category] += 1
                break 

    if matched_categories:
        matched_reviews.append({
            "App Name": app_name,
            "User Name": user,
            "Review Content": row["Review Content"],
            "Matched Categories": "; ".join(matched_categories)
        })


matched_df = pd.DataFrame(matched_reviews)
matched_df.to_csv(os.path.join(output_folder, "profile_behavior_reviews.csv"), index=False)


summary_rows = []
for app, cat_counts in summary_by_app.items():
    row = {"App Name": app}
    row.update(cat_counts)
    summary_rows.append(row)

summary_df = pd.DataFrame(summary_rows).fillna(0)
summary_df.to_csv(os.path.join(output_folder, "profile_behavior_summary.csv"), index=False)

print("✓ Done! Reviews and summary saved.")
