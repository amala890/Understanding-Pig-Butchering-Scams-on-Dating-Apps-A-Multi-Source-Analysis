import pandas as pd
import os
import re
from collections import defaultdict


platform_indicators = {
    "crypto_wallets": ["crypto wallet", "blockchain address", "BTC address", "ETH wallet"],
    "investment_sites": ["investment portal", "trading platform", "forex site", "binance", "coinbase", "fake exchange", "binanace"],
    "payment_apps": ["PayPal", "Venmo", "CashApp", "Zelle", "Western Union"],
    "whatsapp": ["whatsapp", "whats app"],
    "telegram": ["telegram", "tele gram"],
    "instagram": ["instagram", "insta"],
    "facebook": ["facebook", "fb messenger"],
    "snapchat": ["snapchat", "snap chat"],
    "skype": ["skype"],
    "signal": ["signal"],
    "line": ["line app"],
    "wechat": ["wechat", "we chat"],
    "suspicious_links": ["suspicious link", "phishing site", "fake website", "http://", "https://"]
}


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


try:
    df1 = pd.read_csv(victim_reviews_file1, encoding="utf-8-sig")
    df2 = pd.read_csv(victim_reviews_file2, encoding="utf-8-sig")
except UnicodeDecodeError:
    df1 = pd.read_csv(victim_reviews_file1, encoding="ISO-8859-1")
    df2 = pd.read_csv(victim_reviews_file2, encoding="ISO-8859-1")


combined_df = pd.concat([df1, df2], ignore_index=True)


platform_matched_reviews = []
platform_summary_by_app = defaultdict(lambda: defaultdict(int))


for _, row in combined_df.iterrows():
    app_name = row["App Name"]
    user_name = row["User Name"]
    content = str(row["Review Content"]).lower()
    matched_platforms = []

    for platform_type, keywords in platform_indicators.items():
        for keyword in keywords:
            if re.search(re.escape(keyword.lower()), content):
                matched_platforms.append(platform_type)
                platform_summary_by_app[app_name][platform_type] += 1
                break  

    if matched_platforms:
        platform_matched_reviews.append({
            "App Name": app_name,
            "User Name": user_name,
            "Review Content": row["Review Content"],
            "Matched Platforms": "; ".join(set(matched_platforms))
        })


platform_df = pd.DataFrame(platform_matched_reviews)
platform_df.to_csv(os.path.join(output_folder, "platform_mentions_reviews.csv"), index=False)


summary_rows = []
for app, platform_counts in platform_summary_by_app.items():
    row = {"App Name": app}
    row.update(platform_counts)
    summary_rows.append(row)

summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv(os.path.join(output_folder, "platform_mentions_summary.csv"), index=False)

print("✓ Platform mentions analysis complete. Files saved.")
