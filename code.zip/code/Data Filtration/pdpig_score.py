import pandas as pd
import os


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


def load_csv(filepath):
    try:
        return pd.read_csv(filepath)
    except UnicodeDecodeError:
        return pd.read_csv(filepath, encoding='ISO-8859-1')

df1 = load_csv(victim_reviews_file1)
df2 = load_csv(victim_reviews_file2)
combined_df = pd.concat([df1, df2], ignore_index=True)


low_score_df = combined_df[combined_df['Score'].isin([1, 2])].copy()
low_score_df["Review Content"] = low_score_df["Review Content"].astype(str).fillna("")


def classify_issue(text):
    text = text.lower()
    if "crypto" in text or "investment" in text or "bitcoin" in text:
        return "Crypto Scam"
    elif "love" in text or "romance" in text or "relationship" in text:
        return "Romance Scam"
    elif "money" in text or "payment" in text or "transfer" in text:
        return "Financial Scam"
    elif "blocked" in text or "disappear" in text:
        return "Ghosting/Exit Scam"
    else:
        return "Other"


low_score_df["Detected Issue"] = low_score_df["Review Content"].apply(classify_issue)


low_score_output_file = os.path.join(output_folder, "low_score_reviews_with_issues.csv")
low_score_df.to_csv(low_score_output_file, index=False, encoding='utf-8-sig')


summary = low_score_df.groupby(["App Name", "Detected Issue"]).size().reset_index(name="Count")
summary_output_file = os.path.join(output_folder, "low_score_issue_summary.csv")
summary.to_csv(summary_output_file, index=False, encoding='utf-8-sig')

print("✅ Low score review analysis complete. Results saved.")
