import pandas as pd
import os
import re
from collections import defaultdict


timing_indicators = {
    "quick_escalation": [
        r"within days", r"suddenly asked", r"out of nowhere",
        r"started talking about money", r"pivot to investments",
        r"within a week", r"few days later", r"quickly changed"
    ],
    "delayed_escalation": [
        r"after weeks", r"months later", r"gained trust first",
        r"waited before asking", r"months", r"weeks"
    ]
}


victim_reviews_file1 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
victim_reviews_file2 = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


try:
    df1 = pd.read_csv(victim_reviews_file1, encoding="utf-8-sig")
    df2 = pd.read_csv(victim_reviews_file2, encoding="utf-8-sig")
except UnicodeDecodeError:
    df1 = pd.read_csv(victim_reviews_file1, encoding="ISO-8859-1")
    df2 = pd.read_csv(victim_reviews_file2, encoding="ISO-8859-1")


combined_df = pd.concat([df1, df2], ignore_index=True)


timing_matched_reviews = []
timing_summary_by_app = defaultdict(lambda: {"quick_escalation": 0, "delayed_escalation": 0})


for _, row in combined_df.iterrows():
    app_name = row["App Name"]
    user = row["User Name"]
    content = str(row["Review Content"]).lower()

    matched_timing = []

    for timing_type, patterns in timing_indicators.items():
        for pattern in patterns:
            if re.search(pattern, content):
                matched_timing.append(timing_type)
                timing_summary_by_app[app_name][timing_type] += 1
                break  # only count once per category

    if matched_timing:
        timing_matched_reviews.append({
            "App Name": app_name,
            "User Name": user,
            "Review Content": row["Review Content"],
            "Matched Timing Pattern": "; ".join(set(matched_timing))
        })


timing_df = pd.DataFrame(timing_matched_reviews)
timing_df.to_csv(os.path.join(output_folder, "timing_patterns_reviews.csv"), index=False)


summary_rows = []
for app, counts in timing_summary_by_app.items():
    row = {"App Name": app}
    row.update(counts)
    summary_rows.append(row)

summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv(os.path.join(output_folder, "timing_patterns_summary.csv"), index=False)

print("✓ Timing patterns analysis complete. Files saved.")
