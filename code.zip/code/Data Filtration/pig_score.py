import pandas as pd
import os


victim_reviews_file = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews_extra.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


df = pd.read_csv(victim_reviews_file)


df['Score'] = pd.to_numeric(df['Score'], errors='coerce')


low_score_df = df[df['Score'].isin([1, 2])].copy()


def tag_review_type(text):
    text = str(text).lower()
    if "crypto" in text or "investment" in text or "bitcoin" in text:
        return "Crypto Scam"
    elif "love" in text or "romance" in text or "relationship" in text:
        return "Romance Scam"
    elif "money" in text or "payment" in text or "transfer" in text:
        return "Financial Scam"
    elif "blocked" in text or "disappear" in text:
        return "Ghosting/Exit Scam"
    else:
        return "Other"

low_score_df["Review Type"] = low_score_df["Review Content"].apply(tag_review_type)


score_summary = low_score_df["Score"].value_counts().sort_index()


app_summary = low_score_df.groupby("App Name").size().reset_index(name="Low Score Count")


type_summary = low_score_df["Review Type"].value_counts().reset_index()
type_summary.columns = ["Review Type", "Count"]


low_score_file = os.path.join(output_folder, "low_score_reviews.csv")
low_score_df.to_csv(low_score_file, index=False)


summary_file = os.path.join(output_folder, "low_score_summary.csv")
with open(summary_file, "w", encoding="utf-8") as f:
    f.write("=== Low Score Value Counts (1 and 2) ===\n")
    f.write(score_summary.to_string())
    f.write("\n\n=== Low Score Count by App Name ===\n")
    f.write(app_summary.to_string(index=False))
    f.write("\n\n=== Review Type Breakdown (in Low Score Reviews) ===\n")
    f.write(type_summary.to_string(index=False))

print("✅ Analysis complete. CSVs saved:")
print(f"- Low Score Reviews: {low_score_file}")
print(f"- Summary: {summary_file}")
