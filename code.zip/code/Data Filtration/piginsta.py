import os
import pandas as pd
import re


instagram_folder = r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Instagram csv"  # change to your folder
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\gpay_count"
os.makedirs(output_folder, exist_ok=True)


victim_keywords = [
    "romance scam", "pig butchering", "investment scam", "crypto romance scam", "financial scam",
    "crypto fraud", "crypto scheme", "crypto trading scam", "lost my savings", "fake investment", "fake platform",
    "asked me to invest", "pushed me to invest", "asked me to download an app", "they introduced me to a mentor",
    "built trust and then", "pressured me to invest", "sent me a trading link", "i was added to a crypto group",
    "talked for weeks before asking for money", "he said he was a crypto trader", "she said she worked in crypto",
    "claimed to help me invest", "showed fake profits", "sent screenshots of returns", "i trusted them with my savings",
    "couldn’t withdraw", "wallet got drained", "they tricked me", "they promised high returns", "used a fake trading app",
    "sent money and then they disappeared", "they ghosted me after i sent money", 
    "said we were soulmates and then asked for bitcoin", "said they lived abroad and needed help",
    "they wanted me to transfer crypto", "i lost thousands", "money vanished", "i got duped", "i was defrauded",
    "they convinced me to invest", "he made me believe it was real", "promised guaranteed profits",
    "told me i could double my money", "we met on a dating app and then...", "fake broker", "binance scam",
    "metamask scam", "they blocked me after i paid", "i thought it was love", 
    "everything seemed perfect until money came up"
]


dating_apps = [
    "3fun", "aisle", "amolatina", "anonymous", "ashleymadison", "asiandate", "badoo", "blackcupid", "blindmate",
    "bloom", "boo", "bristlr", "bumble", "bumpy", "csl", "casualx", "chatanddate", "choiceoflove", "christianmingle",
    "coffeemeetsbagel", "cougard", "datemyage", "dating.com", "datingevermatch", "datingihappydate", "dilmil",
    "feeld", "feels", "finally", "flirtini", "fotostrana", "fruitz", "hornet", "hush", "interracialcupid", "jaumo",
    "joyce", "jswipe", "lovely", "lovetastic", "millionairematch", "Match", "meet5", "meetme", "mingle2", "muzmatch", "mymatch",
    "okcupid", "once", "paktor", "parship", "plentyoffish", "pure", "randomchat", "romeo", "scruff", "seeking",
    "skout", "smitten", "snoggle", "sweetmeet2", "sweetmeet", "tabor", "tagged", "taimi", "tantan", "teamo",
    "theinnercircle", "theleague", "tinder", "udolly", "urmytype", "waplog", "wild", "wink", "wooplus", "yoomee",
    "yubo", "zendate", "zoe", "zoosk", "eharmony", "eris", "evendating", "g33kdating", "glambu", "grindr", "growlr",
    "happn", "Her app", "hily", "hinge", "Hinge", "honey", "hoop", "kippo", "kismia", "lovescout24", "lovoo", "luxy", "mamba"
]


dating_apps_lower = [app.lower() for app in dating_apps]
victim_keywords_lower = [k.lower() for k in victim_keywords]


result_rows = []
app_mentions = {}


for file in os.listdir(instagram_folder):
    if file.endswith(".csv"):
        file_path = os.path.join(instagram_folder, file)
        df = pd.read_csv(file_path)

        for _, row in df.iterrows():
            caption = str(row.get("caption", "")).lower()
            post_url = row.get("post_url", "")
            likes = row.get("likes", "")

            
            if not any(vk in caption for vk in victim_keywords_lower):
                continue

            
            matched_app = "Nil"
            sorted_apps = sorted(dating_apps_lower, key=lambda x: -len(x))  

            for app in sorted_apps:
                pattern = r'\b' + re.escape(app) + r'\b'
                if re.search(pattern, caption):
                    matched_app = app
                    break

            app_mentions[matched_app] = app_mentions.get(matched_app, 0) + 1

            result_rows.append({
                "InstagramFile": file,
                "Caption": caption,
                "Post URL": post_url,
                "Likes": likes,
                "App name": matched_app
            })


results_df = pd.DataFrame(result_rows)
results_df.drop_duplicates(subset=["InstagramFile", "Caption", "Post URL", "App name"], inplace=True)
results_df.to_csv(os.path.join(output_folder, "instagram_filtered_victim_reviews.csv"), index=False)


summary_df = pd.DataFrame(list(app_mentions.items()), columns=["App name", "Mentions"])
summary_df.to_csv(os.path.join(output_folder, "instagram_app_mentions_summary.csv"), index=False)

print("✅ Filtered Instagram victim reviews and app mentions saved.")
