import pandas as pd
import os


victim_reviews_file = "C:\\Users\\hp\\Desktop\\thu\\victim_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\gpay_count"


os.makedirs(output_folder, exist_ok=True)


platform_indicators = {
    "crypto_wallets": ["crypto wallet", "blockchain address", "BTC address", "ETH wallet"],
    "investment_sites": ["investment portal", "trading platform", "forex site", "binance", "coinbase", "fake exchange"],
    "payment_apps": ["PayPal", "Venmo", "CashApp", "Zelle", "Western Union"],
    "whatsapp": ["whatsapp", "whats app"],
    "telegram": ["telegram", "tele gram"],
    "instagram": ["instagram", "insta"],
    "facebook": ["facebook", "fb messenger"],
    "snapchat": ["snapchat", "snap chat"],
    "skype": ["skype"],
    "signal": ["signal"],
    "line": ["line app"],
    "wechat": ["wechat", "we chat"],
    "suspicious_links": ["suspicious link", "phishing site", "fake website", "http://", "https://"]
}


df = pd.read_csv(victim_reviews_file, encoding="ISO-8859-1", on_bad_lines='skip')



results = []
summary = {}


for index, row in df.iterrows():
    app = row.get("App Name", "")
    review = str(row.get("Review Content", "")).lower()
    matches = []

    for category, keywords in platform_indicators.items():
        if any(keyword.lower() in review for keyword in keywords):
            matches.append(category)
            summary.setdefault(category, {}).setdefault(app, 0)
            summary[category][app] += 1

    if matches:
        results.append({
            "App Name": app,
            "User Name": row.get("User Name", ""),
            "Review Content": row.get("Review Content", ""),
            "Matched Platforms": ", ".join(matches)
        })


detailed_df = pd.DataFrame(results)
summary_rows = []

for category, app_counts in summary.items():
    for app, count in app_counts.items():
        summary_rows.append({
            "Platform Category": category,
            "App Name": app,
            "Mentions": count
        })

summary_df = pd.DataFrame(summary_rows)

# Save to CSV
detailed_path = os.path.join(output_folder, "platform_mentions_detailed.csv")
summary_path = os.path.join(output_folder, "platform_mentions_summary.csv")

detailed_df.to_csv(detailed_path, index=False, encoding='utf-8')
summary_df.to_csv(summary_path, index=False, encoding='utf-8')

print("Files saved to:")
print("Detailed:", detailed_path)
print("Summary:", summary_path)
