import pandas as pd
import re


file_path = "C:/Users/hp/Desktop/thu/victim_reviews.csv"
df = pd.read_csv(file_path, sep='\t' if file_path.endswith('.tsv') else ',', encoding='ISO-8859-1')


timing_indicators = {
    "quick_escalation": [
        "within days", "suddenly asked", "out of nowhere",
        "started talking about money", "pivot to investments",
        "within a week", "few days later", "quickly changed"
    ],
    "delayed_escalation": [
        "after weeks", "months later", "gained trust first",
        "waited before asking"
    ]
}


def detect_escalation_timing(text):
    text = str(text).lower()
    quick = any(phrase in text for phrase in timing_indicators["quick_escalation"])
    delayed = any(phrase in text for phrase in timing_indicators["delayed_escalation"])

    if quick and delayed:
        return "mixed"
    elif quick:
        return "quick_escalation"
    elif delayed:
        return "delayed_escalation"
    else:
        return "no_mention"


df["Timing Pattern"] = df["Review Content"].apply(detect_escalation_timing)


output_path = file_path.replace(".csv", "_with_timing.csv")
df.to_csv(output_path, index=False)
print(f"Annotated file saved to: {output_path}")


print("\nTiming Pattern Distribution:\n", df["Timing Pattern"].value_counts())
