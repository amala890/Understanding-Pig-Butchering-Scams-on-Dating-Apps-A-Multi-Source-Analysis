import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


input_file = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv'
df = pd.read_csv(input_file)


output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps'
os.makedirs(output_folder, exist_ok=True)


apps = {
    'Tinder': ['tinder'],
    'Bumble': ['bumble'],
    'Hinge': ['hinge'],
    'OkCupid': ['okcupid', 'ok cupid'],
    'Match': ['match.com', 'match'],
    'other': []
}


def detect_app(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    for app, keywords in apps.items():
        if any(k in text for k in keywords):
            return app
    return 'other'


df['mentioned_app'] = df['content'].apply(detect_app)


mentioned_df = df[df['mentioned_app'] != 'other']
mentioned_df.to_csv(os.path.join(output_folder, 'scam_reviews_with_app_mentions.csv'), index=False, encoding='utf-8')
print("✅ Saved: scam_reviews_with_app_mentions.csv")


app_counts = mentioned_df['mentioned_app'].value_counts().reset_index()
app_counts.columns = ['App', 'Count']

plt.figure(figsize=(8, 5))
sns.barplot(data=app_counts, x='App', y='Count', palette='pastel')
plt.title("Dating App Mentions in Scam Content")
plt.xlabel("Dating App")
plt.ylabel("Number of Mentions")
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'app_mentions_overall.png'), dpi=300)
plt.close()
print("✅ Saved: app_mentions_overall.png")


if 'platform' in mentioned_df.columns:
    platform_app = mentioned_df.groupby(['platform', 'mentioned_app']).size().unstack(fill_value=0)
    platform_app.to_csv(os.path.join(output_folder, 'app_mentions_by_platform.csv'))
    print("✅ Saved: app_mentions_by_platform.csv")

    platform_app.plot(kind='bar', stacked=True, figsize=(10, 6), colormap='Set2')
    plt.title("Dating App Mentions by Platform")
    plt.xlabel("Platform")
    plt.ylabel("Count")
    plt.legend(title="App", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, 'app_mentions_by_platform.png'), dpi=300)
    plt.close()
    print("✅ Saved: app_mentions_by_platform.png")
