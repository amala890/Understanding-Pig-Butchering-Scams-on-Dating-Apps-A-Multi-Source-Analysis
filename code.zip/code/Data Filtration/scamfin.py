import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import re
import numpy as np
import os


input_file = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv'
df = pd.read_csv(input_file)


output_folder = r'C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smp'
os.makedirs(output_folder, exist_ok=True)


def extract_financial_loss(text):
    if pd.isna(text):
        return np.nan
    text = str(text).lower()
    matches = re.findall(r'\$?\d{1,3}(?:,\d{3})*(?:\.\d{2})?\s*(dollars|usd)?', text)
    for match in matches:
        value = re.sub(r'[^\d.]', '', match)
        try:
            return float(value)
        except:
            continue
    return np.nan

df['financial_loss'] = df['content'].apply(extract_financial_loss)


df.to_csv(os.path.join(output_folder, 'scam_reviews_with_financial_loss.csv'), index=False, encoding='utf-8')
print("✅ Saved: scam_reviews_with_financial_loss.csv")


plt.figure(figsize=(10, 6))
sns.histplot(df['financial_loss'].dropna(), bins=20, kde=True, color='tomato')
plt.title("Distribution of Financial Losses")
plt.xlabel("Financial Loss ($)")
plt.ylabel("Number of Reports")
plt.tight_layout()
plt.savefig(os.path.join(output_folder, 'financial_loss_distribution.png'), dpi=300)
plt.close()
print("✅ Saved: financial_loss_distribution.png")


summary_stats = {
    'Total Reports': len(df),
    'Reports with Loss Mentioned': df['financial_loss'].notna().sum(),
    'Average Financial Loss ($)': round(df['financial_loss'].mean(), 2),
    'Maximum Financial Loss Reported ($)': df['financial_loss'].max()
}
summary_df = pd.DataFrame(list(summary_stats.items()), columns=['Metric', 'Value'])
summary_df.to_csv(os.path.join(output_folder, 'financial_loss_stats.csv'), index=False)
print("✅ Saved: financial_loss_stats.csv")


if 'dating_app' in df.columns:
    app_loss = df.groupby('dating_app')['financial_loss'].sum().sort_values(ascending=False)
    app_loss_df = app_loss.reset_index()
    app_loss_df.to_csv(os.path.join(output_folder, 'financial_loss_by_dating_app.csv'), index=False)
    print("✅ Saved: financial_loss_by_dating_app.csv")

    plt.figure(figsize=(8, 5))
    sns.barplot(x='financial_loss', y='dating_app', data=app_loss_df, palette='YlOrRd')
    plt.title("Total Financial Loss by Dating App")
    plt.xlabel("Financial Loss ($)")
    plt.ylabel("Dating App")
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, 'financial_loss_by_dating_app.png'), dpi=300)
    plt.close()
    print("✅ Saved: financial_loss_by_dating_app.png")


if 'platform' in df.columns:
    platform_loss = df.groupby('platform')['financial_loss'].sum().sort_values(ascending=False)
    platform_loss_df = platform_loss.reset_index()
    platform_loss_df.to_csv(os.path.join(output_folder, 'financial_loss_by_platform.csv'), index=False)
    print("✅ Saved: financial_loss_by_platform.csv")

    plt.figure(figsize=(8, 5))
    sns.barplot(x='financial_loss', y='platform', data=platform_loss_df, palette='BuGn_r')
    plt.title("Total Financial Loss by Platform")
    plt.xlabel("Financial Loss ($)")
    plt.ylabel("Platform")
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, 'financial_loss_by_platform.png'), dpi=300)
    plt.close()
    print("✅ Saved: financial_loss_by_platform.png")
