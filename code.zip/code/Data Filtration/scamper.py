
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os


input_file = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps\scam_related_social_posts.csv"
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\res_smps"
os.makedirs(output_folder, exist_ok=True)


df = pd.read_csv(input_file)


def extract_scammer_persona(text):
    personas = {
        'businessman': ['businessman', 'entrepreneur', 'executive', 'ceo', 'investor'],
        'professional': ['doctor', 'engineer', 'lawyer', 'military', 'pilot'],
        'wealthy': ['rich', 'wealthy', 'successful', 'millionaire'],
        'other': []
    }

    if pd.isna(text):
        return 'unknown'
    
    text = str(text).lower()
    for persona, keywords in personas.items():
        if any(keyword in text for keyword in keywords):
            return persona
    return 'other'


df['scammer_persona'] = df['content'].apply(extract_scammer_persona)


persona_output = os.path.join(output_folder, 'scam_posts_with_personas.csv')
df.to_csv(persona_output, index=False)
print(f"✅ Data with scammer personas saved to:\n{persona_output}")


sns.set_style("whitegrid")
plt.figure(figsize=(8, 6))
persona_counts = df['scammer_persona'].value_counts()
persona_counts.plot(kind='bar', color='skyblue')
plt.title("Scammer Personas Mentioned in Social Media Posts")
plt.xlabel("Persona")
plt.ylabel("Count")
plt.xticks(rotation=45)
plt.tight_layout()


persona_bar_path = os.path.join(output_folder, 'scammer_personas_bar_chart_social.png')
plt.savefig(persona_bar_path, dpi=300)
plt.close()
print(f"✅ Bar chart saved to:\n{persona_bar_path}")


grouped = df.groupby(['platform', 'scammer_persona']).size().unstack().fillna(0)


platform_counts_path = os.path.join(output_folder, 'scammer_personas_by_platform.csv')
grouped.to_csv(platform_counts_path)
print(f"✅ Scammer persona counts by platform saved to:\n{platform_counts_path}")


plt.figure(figsize=(12, 7))
ax = grouped.plot(kind='bar', colormap='viridis', edgecolor='black')
plt.title("Scammer Personas by Platform")
plt.xlabel("Platform")
plt.ylabel("Count")
plt.xticks(rotation=45, ha='right')
plt.legend(title='Scammer Persona', bbox_to_anchor=(1.05, 1), loc='upper left')


for container in ax.containers:
    ax.bar_label(container, label_type='edge', padding=2, fontsize=9)

plt.tight_layout()
grouped_bar_path = os.path.join(output_folder, 'scammer_personas_grouped_by_platform.png')
plt.savefig(grouped_bar_path, dpi=300)
plt.close()
print(f"✅ Grouped bar chart saved to:\n{grouped_bar_path}")


dating_apps = [
    'tinder', 'match', 'hinge', 'unknown', 'other'
]

def extract_app_name(text):
    if pd.isna(text):
        return 'unknown'
    text = str(text).lower()
    for app in dating_apps:
        if app in text:
            return app
    return 'unknown'


df['app_mentioned'] = df['content'].apply(extract_app_name)

persona_by_app = df.groupby(['app_mentioned', 'scammer_persona']).size().unstack().fillna(0)


persona_by_app_csv = os.path.join(output_folder, 'scammer_personas_by_app.csv')
persona_by_app.to_csv(persona_by_app_csv)
print(f"✅ Scammer persona counts by dating app saved to:\n{persona_by_app_csv}")


plt.figure(figsize=(14, 8))
ax2 = persona_by_app.plot(kind='bar', colormap='Set2', edgecolor='black')
plt.title("Scammer Personas by Dating App (From Social Media Posts)")
plt.xlabel("Dating App Mentioned")
plt.ylabel("Count")
plt.xticks(rotation=45, ha='right')
plt.legend(title='Scammer Persona', bbox_to_anchor=(1.05, 1), loc='upper left')


for container in ax2.containers:
    ax2.bar_label(container, label_type='edge', padding=2, fontsize=9)

plt.tight_layout()
persona_by_app_chart = os.path.join(output_folder, 'scammer_personas_by_app_chart.png')
plt.savefig(persona_by_app_chart, dpi=300)
plt.close()
print(f"✅ Scammer personas by app chart saved to:\n{persona_by_app_chart}")
