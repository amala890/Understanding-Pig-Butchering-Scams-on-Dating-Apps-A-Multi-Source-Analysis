import pandas as pd
import os


tactics = {
    'investment': ['invest', 'investment', 'crypto', 'bitcoin', 'ethereum', 'blockchain', 'stock', 'profit', 'return', 'ROI', 'forex', 'trading','binance'],
    'emergency': ['emergency', 'urgent', 'hospital', 'accident', 'need money', 'broke', 'surgery', 'bill', 'medical', 'debt'],
    'gift': ['gift', 'present', 'customs', 'fee', 'parcel', 'delivery', 'package', 'shipping', 'clearance'],
    'romance': ['love', 'baby', 'darling', 'miss you', 'marry', 'relationship', 'soulmate', 'future together'],
    'job_offer': ['job', 'employment', 'recruit', 'hiring', 'offer', 'income opportunity', 'vacancy'],
    'travel': ['flight', 'travel', 'visa', 'passport', 'ticket', 'trip', 'hotel', 'abroad']
}


instagram_file = "C:\\Users\\hp\\Desktop\\thu\\instagram_filtered_victim_reviews.csv"
reddit_file = "C:\\Users\\hp\\Desktop\\thu\\reddit_scam_reviews.csv"
twitter_file = "C:\\Users\\hp\\Desktop\\thu\\twitter_scam_reviews.csv"
output_folder = "C:\\Users\\hp\\Desktop\\Thesis\\Project\\Full_code_Amala (1)\\Full_code_Amala\\1722_count"

os.makedirs(output_folder, exist_ok=True)


def classify_tactics(text):
    text = text.lower()
    found_tactics = []
    for tactic, keywords in tactics.items():
        if any(keyword in text for keyword in keywords):
            found_tactics.append(tactic)
    return found_tactics if found_tactics else ['none']


df_insta = pd.read_csv(instagram_file)
df_insta['Platform'] = 'Instagram'
df_insta['Text'] = df_insta['Caption'].astype(str)
df_insta['Tactics'] = df_insta['Text'].apply(classify_tactics)


df_reddit = pd.read_csv(reddit_file)
df_reddit['Platform'] = 'Reddit'
df_reddit['Text'] = df_reddit['Post Content'].astype(str)
df_reddit['Tactics'] = df_reddit['Text'].apply(classify_tactics)


df_twitter = pd.read_csv(twitter_file)
df_twitter['Platform'] = 'Twitter'
df_twitter['Text'] = df_twitter['Tweet Text'].astype(str)
df_twitter['Tactics'] = df_twitter['Text'].apply(classify_tactics)


all_data = pd.concat([df_insta, df_reddit, df_twitter], ignore_index=True)
all_data['App Name'] = all_data['App name'].fillna('Nil')


exploded = all_data.explode('Tactics')


exploded.to_csv(os.path.join(output_folder, "tactic_tagged_reviews.csv"), index=False)


summary = exploded.groupby(['App Name', 'Tactics']).size().unstack(fill_value=0)
summary.to_csv(os.path.join(output_folder, "tactic_summary_by_app.csv"))


platform_summary = exploded.groupby(['Platform', 'Tactics']).size().unstack(fill_value=0)
platform_summary.to_csv(os.path.join(output_folder, "tactic_summary_by_platform.csv"))

print("✅ Tactic tagging and summaries saved.")
