import os
import pandas as pd
from collections import defaultdict
import re


dating_apps = [
    "3fun",
    "aisle",
    "amolatina",
    "anonymous",
    "ashleymadison",
    "asiandate",
    "badoo",
    "blackcupid",
    "blindmate",
    "bloom",
    "boo",
    "bristlr",
    "bumble",
    "bumpy",
    "csl",
    "casualx",
    "chatanddate",
    "choiceoflove",
    "christianmingle",
    "coffeemeetsbagel",
    "cougard",
    "datemyage",
    "dating.com",
    "datingevermatch",
    "datingihappydate",
    "dilmil",
    "feeld",
    "feels",
    "finally",
    "flirtini",
    "fotostrana",
    "fruitz",
    "hornet",
    "hush",
    "interracialcupid",
    "jaumo",
    "joyce",
    "jswipe",
    "lovely",
    "lovetastic",
    "mm",
    "match",
    "meet5",
    "meetme",
    "mingle2",
    "muzmatch",
    "mymatch",
    "okcupid",
    "once",
    "paktor",
    "parship",
    "plentyoffish",
    "pure",
    "randomchat",
    "romeo",
    "scruff",
    "seeking",
    "skout",
    "smitten",
    "snoggle",
    "sweetmeet2",
    "sweetmeet",
    "tabor",
    "tagged",
    "taimi",
    "tantan",
    "teamo",
    "theinnercircle",
    "theleague",
    "tinder",
    "udolly",
    "urmytype",
    "waplog",
    "wild",
    "wink",
    "wooplus",
    "yoomee",
    "yubo",
    "zendate",
    "zoe",
    "zoosk",
    "eharmony",
    "eris",
    "evendating",
    "g33kdating",
    "glambu",
    "grindr",
    "growlr",
    "happn",
    "her",
    "hily",
    "hinge",
    "honey",
    "hoop",
    "kippo",
    "kismia",
    "lovescout24",
    "lovoo",
    "luxy",
    "mamba"
]



victim_keywords = [
    "romance scam", "pig butchering", "crypto scam", "investment scam", "crypto romance scam",
    "financial scam", "crypto fraud", "crypto scheme", "crypto trading scam", "lost my savings",
    "fake investment", "fake platform", "asked me to invest", "pushed me to invest",
    "asked me to download an app", "they introduced me to a mentor", "built trust and then",
    "pressured me to invest", "sent me a trading link", "i was added to a crypto group",
    "talked for weeks before asking for money", "he said he was a crypto trader",
    "she said she worked in crypto", "claimed to help me invest", "showed fake profits",
    "sent screenshots of returns", "i trusted them with my savings", "couldn’t withdraw",
    "wallet got drained", "they tricked me", "they promised high returns", "used a fake trading app",
    "sent money and then they disappeared", "they ghosted me after i sent money",
    "said we were soulmates and then asked for bitcoin", "said they lived abroad and needed help",
    "they wanted me to transfer crypto", "i lost thousands", "money vanished", "i got duped",
    "i was defrauded", "they convinced me to invest", "he made me believe it was real",
    "promised guaranteed profits", "told me i could double my money",
    "we met on a dating app and then...", "fake broker", "binance scam", "metamask scam",
    "they blocked me after i paid", "i thought it was love", "everything seemed perfect until money came up"
]

def classify_caption(text):
    text = str(text).lower()
    for keyword in victim_keywords:
        if keyword in text:
            return "Victim"
    return "Not Scam Related"

def extract_other_apps(text, known_apps):
    text = text.lower()
    words = re.findall(r'\b[a-z][a-z0-9\-]{2,}\b', text)
    other_apps = set()
    for word in words:
        if word not in known_apps and "app" in text and len(word) > 3:
            other_apps.add(word)
    return list(other_apps)

def process_instagram_posts(folder_path):
    results = defaultdict(lambda: {
        "Victims": 0,
        "Scammer Mentions": 0,
        "Total Posts": 0,
        "Dating App Mentions": defaultdict(int),
        "Other Apps Mentioned": []
    })
    all_posts = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            app_name = file.split('.')[0]
            file_path = os.path.join(folder_path, file)
            df = pd.read_csv(file_path)

            if "caption" not in df.columns:
                print(f"Skipping {file} due to missing 'caption' column.")
                continue

            for _, row in df.iterrows():
                caption_text = str(row["caption"])
                category = classify_caption(caption_text)

                results[app_name]["Total Posts"] += 1
                if category == "Victim":
                    results[app_name]["Victims"] += 1

                    for app in dating_apps:
                        if app in caption_text.lower():
                            results[app_name]["Dating App Mentions"][app] += 1

                    other_apps = extract_other_apps(caption_text, dating_apps)
                    if other_apps:
                        results[app_name]["Other Apps Mentioned"].extend(other_apps)

                all_posts.append([app_name, caption_text, category])

    return results, all_posts

def save_results(results, all_posts, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    
   
    summary_data = []
    for app_name, data in results.items():
        row = {
            "InstagramFile": app_name,
            "Victims": data["Victims"],
            "Total Posts": data["Total Posts"]
        }
       
        for app in dating_apps:
            row[app] = data["Dating App Mentions"].get(app, 0)

       
        other_apps_cleaned = set(data["Other Apps Mentioned"])
        row["Other Apps Mentioned"] = ", ".join(sorted(other_apps_cleaned))
        summary_data.append(row)

    summary_df = pd.DataFrame(summary_data)

   
    total_row = {
        "InstagramFile": "Total",
        "Victims": summary_df["Victims"].sum(),
        "Total Posts": summary_df["Total Posts"].sum(),
    }
    for app in dating_apps:
        total_row[app] = summary_df[app].sum() if app in summary_df.columns else 0
    total_row["Other Apps Mentioned"] = ""  
    summary_df = pd.concat([summary_df, pd.DataFrame([total_row])], ignore_index=True)

    # Save results
    summary_df.to_csv(os.path.join(output_folder, "instagram_scam_summary.csv"), index=False)
    posts_df = pd.DataFrame(all_posts, columns=["InstagramFile", "Caption", "Category"])
    posts_df.to_csv(os.path.join(output_folder, "instagram_classified_posts.csv"), index=False)

    print("✅ Instagram processing complete. Results saved.")


folder_path = r"C:\Users\hp\Desktop\Full_code_Amala_Romance\Instagram csv"
output_folder = r"C:\Users\hp\Desktop\Thesis\Project\Full_code_Amala (1)\Full_code_Amala\result"

results, all_posts = process_instagram_posts(folder_path)
save_results(results, all_posts, output_folder)
